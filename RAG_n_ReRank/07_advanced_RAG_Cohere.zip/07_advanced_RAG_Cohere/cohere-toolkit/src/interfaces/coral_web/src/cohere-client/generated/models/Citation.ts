/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Citation = {
  text: string;
  start: number;
  end: number;
  document_ids: Array<string>;
};
