/* generated using openapi-typescript-codegen -- do no edit */

/* istanbul ignore file */

/* tslint:disable */

/* eslint-disable */
import type { ToolInputType } from './ToolInputType';

export type StreamToolInput = {
  is_finished: boolean;
  input_type: ToolInputType;
  tool_name: string;
  input: string;
  text: string;
};
