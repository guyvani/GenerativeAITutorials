/* generated using openapi-typescript-codegen -- do no edit */

/* istanbul ignore file */

/* tslint:disable */

/* eslint-disable */
import type { Document } from './Document';

export type StreamSearchResults = {
  is_finished: boolean;
  search_results?: Array<Record<string, any>>;
  documents?: Array<Document>;
};
