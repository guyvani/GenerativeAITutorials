/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Type of input passed to the tool
 */
export enum ToolInputType {
  QUERY = 'QUERY',
  CODE = 'CODE',
}
