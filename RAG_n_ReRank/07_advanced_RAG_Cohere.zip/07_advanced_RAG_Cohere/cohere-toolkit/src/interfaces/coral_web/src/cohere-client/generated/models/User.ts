/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type User = {
  fullname: string;
  email?: string | null;
  id: string;
  created_at: string;
  updated_at: string;
};
