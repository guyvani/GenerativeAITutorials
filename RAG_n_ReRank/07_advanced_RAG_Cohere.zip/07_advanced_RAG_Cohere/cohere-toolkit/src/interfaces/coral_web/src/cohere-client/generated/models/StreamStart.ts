/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Stream start event.
 */
export type StreamStart = {
  is_finished: boolean;
  generation_id: string;
  conversation_id?: string | null;
};
