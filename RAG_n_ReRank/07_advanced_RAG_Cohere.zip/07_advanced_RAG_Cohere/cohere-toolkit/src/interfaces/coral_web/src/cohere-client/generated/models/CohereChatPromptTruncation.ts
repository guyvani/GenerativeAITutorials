/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Dictates how the prompt will be constructed. Defaults to "AUTO_PRESERVE_ORDER".
 */
export enum CohereChatPromptTruncation {
  OFF = 'OFF',
  AUTO_PRESERVE_ORDER = 'AUTO_PRESERVE_ORDER',
}
