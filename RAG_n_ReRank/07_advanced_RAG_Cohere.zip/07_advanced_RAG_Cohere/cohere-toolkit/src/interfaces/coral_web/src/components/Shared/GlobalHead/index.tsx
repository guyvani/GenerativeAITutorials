export * from './GlobalHead';
