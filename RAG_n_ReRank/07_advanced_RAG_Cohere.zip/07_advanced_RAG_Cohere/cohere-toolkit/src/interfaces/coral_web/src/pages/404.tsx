import { PageNotFound } from '@/components/Shared';

const Page = () => {
  return <PageNotFound />;
};

export default Page;
