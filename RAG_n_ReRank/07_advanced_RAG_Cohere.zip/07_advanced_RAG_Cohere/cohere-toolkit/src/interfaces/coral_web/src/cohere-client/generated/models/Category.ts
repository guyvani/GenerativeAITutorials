/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export enum Category {
  FILE_LOADER = 'File loader',
  DATA_LOADER = 'Data loader',
  FUNCTION = 'Function',
}
