import { useState } from 'react';

import { Button, Input, Spinner, Text } from '@/components/Shared';
import { useEditConversation } from '@/hooks/conversation';
import { useConversationStore } from '@/stores';

type Props = {
  conversationId: string;
  initialConversationTitle: string;
  onClose: VoidFunction;
};

export const EditConversationTitle: React.FC<Props> = ({
  conversationId = '',
  initialConversationTitle,
  onClose,
}) => {
  const [title, setTitle] = useState(initialConversationTitle);
  const [errorMessage, setErrorMessage] = useState('');

  const { mutateAsync: editConversation, isPending } = useEditConversation();
  const { setConversation } = useConversationStore();

  const onConfirm = async () => {
    try {
      setErrorMessage('');
      await editConversation({ conversationId, title });

      if (window?.location.pathname.includes(conversationId)) {
        setConversation({ name: title });
      }
      onClose();
    } catch {
      setErrorMessage('Failed to update conversation title. Please try again.');
    }
  };

  return (
    <div>
      <Input
        label="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        disabled={isPending}
      />

      <Text className="mt-2 text-danger-500 first-letter:uppercase">{errorMessage}</Text>

      <div className="mt-6 flex items-center justify-between">
        <Button kind="secondary" onClick={onClose}>
          Cancel
        </Button>
        <Button onClick={onConfirm} splitIcon="arrow-right" disabled={isPending}>
          {isPending ? <Spinner /> : `Save`}
        </Button>
      </div>
    </div>
  );
};
