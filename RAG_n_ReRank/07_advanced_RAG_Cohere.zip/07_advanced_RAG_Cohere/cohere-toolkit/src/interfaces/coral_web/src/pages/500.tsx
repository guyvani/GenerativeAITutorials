import { PageServerError } from '@/components/Shared';

const Page = () => {
  return <PageServerError />;
};

export default Page;
