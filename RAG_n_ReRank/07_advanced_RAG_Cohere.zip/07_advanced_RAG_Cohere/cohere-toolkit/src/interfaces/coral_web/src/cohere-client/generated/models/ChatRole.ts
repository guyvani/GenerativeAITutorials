/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * One of CHATBOT|USER to identify who the message is coming from.
 */
export enum ChatRole {
  CHATBOT = 'CHATBOT',
  USER = 'USER',
}
