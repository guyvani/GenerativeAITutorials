/* generated using openapi-typescript-codegen -- do no edit */

/* istanbul ignore file */

/* tslint:disable */

/* eslint-disable */
import type { Citation } from './Citation';

/**
 * Stream citation generation event.
 */
export type StreamCitationGeneration = {
  is_finished: boolean;
  citations?: Array<Citation>;
};
