/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UpdateDeploymentEnv = {
  env_vars: Record<string, string>;
};
