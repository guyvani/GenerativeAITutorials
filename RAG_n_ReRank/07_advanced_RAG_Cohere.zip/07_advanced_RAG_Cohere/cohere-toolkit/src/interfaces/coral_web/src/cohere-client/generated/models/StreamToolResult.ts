/* generated using openapi-typescript-codegen -- do no edit */

/* istanbul ignore file */

/* tslint:disable */

/* eslint-disable */
import type { Document } from './Document';

export type StreamToolResult = {
  is_finished: boolean;
  result: string | null;
  documents?: Array<Document>;
};
