export * from './CoralLogo';
