/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Stream query generation event.
 */
export type StreamQueryGeneration = {
  is_finished: boolean;
  query: string;
};
