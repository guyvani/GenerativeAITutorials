/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Stream text generation event.
 */
export type StreamTextGeneration = {
  is_finished: boolean;
  text: string;
};
