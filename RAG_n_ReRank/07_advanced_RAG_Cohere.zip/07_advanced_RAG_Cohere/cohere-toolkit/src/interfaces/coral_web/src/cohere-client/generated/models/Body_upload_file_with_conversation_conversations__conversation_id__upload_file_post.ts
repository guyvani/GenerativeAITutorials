/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Body_upload_file_with_conversation_conversations__conversation_id__upload_file_post = {
  file: Blob;
};
