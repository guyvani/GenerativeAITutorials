/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UploadFile = {
  id: string;
  created_at: string;
  updated_at: string;
  user_id: string;
  conversation_id: string;
  file_name: string;
  file_path: string;
  file_size?: number;
};
