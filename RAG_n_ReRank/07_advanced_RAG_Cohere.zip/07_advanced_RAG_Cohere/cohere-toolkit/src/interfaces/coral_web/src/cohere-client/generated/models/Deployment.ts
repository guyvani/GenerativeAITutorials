/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Deployment = {
  name: string;
  models: Array<string>;
  env_vars: Array<string>;
};
