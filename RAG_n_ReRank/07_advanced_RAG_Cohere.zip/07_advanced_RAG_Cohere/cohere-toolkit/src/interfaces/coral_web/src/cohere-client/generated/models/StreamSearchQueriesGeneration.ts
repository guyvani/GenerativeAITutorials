/* generated using openapi-typescript-codegen -- do no edit */

/* istanbul ignore file */

/* tslint:disable */

/* eslint-disable */
import type { SearchQuery } from './SearchQuery';

/**
 * Stream queries generation event.
 */
export type StreamSearchQueriesGeneration = {
  is_finished: boolean;
  search_queries?: Array<SearchQuery>;
};
