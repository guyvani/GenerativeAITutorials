export * from './InputLabel';
