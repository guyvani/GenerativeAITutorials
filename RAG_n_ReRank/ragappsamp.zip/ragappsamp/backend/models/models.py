from typing import List, Optional
from pydantic import BaseModel


class EnsureResponse(BaseModel):
    message: str


class Metadata(BaseModel):
    offset: int
    source: str
    markdown_url: str
    title: str
    original_url: str
    chunk: int
    key: str
    filename: str


class Citation(BaseModel):
    content: str
    id: str
    chunk_id: int
    title: str
    filepath: str
    url: str
    metadata: Metadata


class FeedbackRequest(BaseModel):
    messageId: str
    stars: int
    comment: Optional[str] = None
    feedbackType: Optional[str] = None


class ConversationInfo(BaseModel):
    id: str
    createdAt: str
    title: str
    type: str
    updatedAt: str
    userId: str


class ConversationRead(BaseModel):
    conversation_id: str


class Feedback(BaseModel):
    stars: int
    comment: Optional[str] = None
    feedback_type: Optional[str] = None


class Message(BaseModel):
    id: str
    content: str
    role: str
    type: str
    createdAt: str
    updatedAt: str
    feedback: Optional[Feedback] = None


class Conversation(BaseModel):
    conversation_id: str
    messages: List[Message]


class RequestMessage(BaseModel):
    content: str
    date: Optional[str] = None
    id: Optional[str] = None
    role: str
    end_turn: Optional[bool] = False


class GenerateRequest(BaseModel):
    conversation_id: Optional[str] = None
    messages: List[RequestMessage]
    promptStyle: str


class HistoryMetadata(BaseModel):
    conversation_id: str
    date: Optional[str] = None
    title: Optional[str] = None


class Choice(BaseModel):
    messages: List[Message]


class GenerateResponse(BaseModel):
    choices: List[Choice]
    created: str
    history_metadata: HistoryMetadata
    id: str
    model: str
    object: str


class DeleteRequest(BaseModel):
    conversation_id: str


class RenameRequest(BaseModel):
    conversation_id: str
    title: str


class DeleteAllResponse(BaseModel):
    message: str


class HistoryReadRequest(BaseModel):
    conversation_id: str


class ClearRequest(BaseModel):
    conversation_id: str