import logging, json
import azure.functions as func
from urllib.parse import urlparse
from utilities.helpers.AzureDataLakeStorageHelper import AzureDataLakeStorageClient
from utilities.helpers.DocumentProcessorHelper import DocumentProcessor
from utilities.helpers.ConfigHelper import ConfigHelper

def _get_file_path_from_message(msg: func.QueueMessage) -> dict:
    message_body = json.loads(msg.get_body().decode('utf-8'))
    return message_body.get('filename', "/".join(urlparse(message_body.get('data', {}).get('url', '')).path.split('/')[2:]))

def main(msg: func.QueueMessage) -> None:
    logging.info('Python queue trigger function processed a queue item: %s',
                 msg.get_body().decode('utf-8'))
    document_processor = DocumentProcessor()
    datalake_client = AzureDataLakeStorageClient()
    # Get the file name from the message
    # filename will be in the format "<directory_path>/<actual_file_name>" with out the container/file system name
    filename = _get_file_path_from_message(msg)
    # directory_path = file_path_dict.get("directory_path")
    # filename = file_path_dict.get("filename")
    # file_path = f'{directory_path}/{filename}'
    # Generate the SAS URL for the file
    file_sas = datalake_client.get_blob_sas(file_path=filename)
    # Get file extension's processors
    file_extension = filename.split(".")[-1]
    processors = list(filter(lambda x: x.document_type == file_extension, ConfigHelper.get_active_config_or_default().document_processors))
    # Process the file
    document_processor.process(source_url=file_sas, processors=processors)
    datalake_client.upsert_blob_metadata(file_name=filename, metadata={'embeddings_added': 'true'})
