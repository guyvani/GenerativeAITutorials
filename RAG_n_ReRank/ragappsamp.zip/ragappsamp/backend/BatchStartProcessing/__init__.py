import logging, json, os
import azure.functions as func
from azure.storage.queue import QueueClient, BinaryBase64EncodePolicy
from utilities.helpers.AzureDataLakeStorageHelper import AzureDataLakeStorageClient

DOCUMENT_PROCESSING_QUEUE_NAME = os.environ['DOCUMENT_PROCESSING_QUEUE_NAME']
AZURE_DATALAKE_DIRECTORY_PATHS_LIST = os.environ['AZURE_DATALAKE_DIRECTORY_PATHS_LIST']

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Requested to start processing all documents received')
    # Split string to list
    directory_paths = AZURE_DATALAKE_DIRECTORY_PATHS_LIST.split(', ')
    # Set up Blob Storage Client
    azure_datalake_storage_client = AzureDataLakeStorageClient()
    # Get all files from Blob Storage
    files_data = azure_datalake_storage_client.get_all_files(directory_paths=directory_paths)
    # Filter out files that have already been processed
    # files_data = list(filter(lambda x : not x['embeddings_added'], files_data)) if req.params.get('process_all') != 'true' else files_data
    # filename will be in the format of "<directory_path>/<actual_file_name>" where directory path does not include the conatainer/file_system_name
    files_data = list(map(lambda x: {'filename': x['filename']}, files_data))
    # Create the QueueClient object
    queue_client = QueueClient.from_connection_string(azure_datalake_storage_client.connect_str, DOCUMENT_PROCESSING_QUEUE_NAME, message_encode_policy=BinaryBase64EncodePolicy())
    # Send a message to the queue for each file
    for fd in files_data:
        queue_client.send_message(json.dumps(fd).encode('utf-8'))
 
    return func.HttpResponse(f"Conversion started successfully for {len(files_data)} documents.", status_code=200)