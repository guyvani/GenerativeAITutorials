import openai
# from openai import OpenAI
# from EnvHelper import EnvHelper
from .LLMHelper import LLMHelper
from langchain.chains.llm import LLMChain
from langchain.prompts import PromptTemplate
import os

proxy = 'zproxy.newyorklife.com:443'
os.environ['http_proxy'] = proxy
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy
os.environ["OPENAI_PROXY"] = 'http://zproxy.newyorklife.com:9480/'

llm_helper = LLMHelper()

def rate_prompt(question):
    prompt_template = (
        f"Rate the following prompt to a RAG model on a scale of 0 to 5. "
        f"5 indicates a good prompt that has details/keywords to answer a question. "
        f"1 indicates worst prompt that lacks details or is not very interrogative or is incomplete. "
        f"Also any words that are not abbreviations and are not words in English vocabulary should be rated 0"
        f"Return only the rating. "
        f"Prompt: cost of insurance, Score: 3"
        f"Prompt: What is the maximum loan amount at POC?, Score: 5"
        f"Prompt: positive suspense, Score: 2"
        f"Prompt: {question}, Score: ")
    prompt = PromptTemplate(input_variables=[], template=prompt_template)
    completion = LLMChain(llm=llm_helper.get_llm(), prompt=prompt)
    score = completion.predict()
    # The LLM sometimes returns a response stating that the question
    # is incomplete and it cannot rate the question since 
    # this function gets called as the user types in the question.
    score = int(score) if score.isdigit() else 0
    return score
