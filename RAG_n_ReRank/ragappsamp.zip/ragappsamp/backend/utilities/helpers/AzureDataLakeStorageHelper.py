from typing import Optional
from datetime import datetime, timedelta
from azure.storage.blob import BlobServiceClient, generate_blob_sas, generate_container_sas, ContentSettings
from azure.storage.filedatalake import DataLakeDirectoryClient, DataLakeFileClient, DataLakeServiceClient, generate_file_sas, generate_directory_sas, generate_file_system_sas, ContentSettings
from .EnvHelper import EnvHelper

class AzureDataLakeStorageClient:
    def __init__(self, account_name: Optional[str] = None, account_key: Optional[str] = None, file_system_name: Optional[str] = None):

        env_helper : EnvHelper = EnvHelper()

        self.account_name = account_name if account_name else env_helper.AZURE_DATALAKE_ACCOUNT_NAME
        self.account_key = account_key if account_key else env_helper.AZURE_DATALAKE_ACCOUNT_KEY
        self.connect_str = f"DefaultEndpointsProtocol=https;AccountName={self.account_name};AccountKey={self.account_key};EndpointSuffix=core.windows.net"
        self.file_system_name : str = file_system_name if file_system_name else env_helper.AZURE_DATALAKE_FILE_SYSTEM_NAME
        self.blob_service_client : BlobServiceClient = BlobServiceClient.from_connection_string(self.connect_str)
        self.datalake_service_client : DataLakeServiceClient = DataLakeServiceClient.from_connection_string(self.connect_str)

    # TODO: Not needed to get and index files from DataLake; add in later if needed
    # def upload_file(self, bytes_data, directory, file_name, content_type='application/pdf'):
    #     # Create a directory client using the local file name as the name for the blob
    #     directory_client = self.datalake_service_client.get_directory_client(file_system=self.file_system_name, directory=directory)
    #     file_client = directory_client.get_file_client()
    #     # Upload the created file
    #     file_client.upload_blob(bytes_data, overwrite=True, content_settings=ContentSettings(content_type=content_type))
    #     # Generate a SAS URL to the blob and return it
    #     return blob_client.url + '?' + generate_blob_sas(self.account_name, self.container_name, file_name,account_key=self.account_key,  permission="r", expiry=datetime.utcnow() + timedelta(hours=3))

    # def download_file(self, file_name):
    #     blob_client = self.blob_service_client.get_blob_client(container=self.container_name, blob=file_name)
    #     return blob_client.download_blob().readall()
    
    # def delete_file(self, file_name):
    #     """
    #     Deletes a file from the Azure Blob Storage container.

    #     Args:
    #         file_name (str): The name of the file to delete.

    #     Returns:
    #         None
    #     """
    #     blob_client = self.blob_service_client.get_blob_client(container=self.container_name, blob=file_name)
    #     blob_client.delete_blob()

    """
        each path in directory_paths will not include the container/file system name in it
        the name returned by doing blob.name from the blob_list will be "<directory_path>/<actual_file_name>"
    """
    def get_all_files(self, directory_paths: list[str]):
        # Get all file paths in the directories from Azure DataLake
        
        file_system_client = self.datalake_service_client.get_file_system_client(file_system=self.file_system_name)
        
        # File system name for DataLake is the same as the container name
        container_client = self.blob_service_client.get_container_client(self.file_system_name)
        blob_list = container_client.list_blobs(include='metadata')
        
        # Generate SAS for DataLake FileSystem as this will allow access to all containers, directories, and files in it
        sas = generate_file_system_sas(
            account_name=self.account_name,
            file_system_name=self.file_system_name,
            credential=self.account_key,
            permission="r",
            expiry=datetime.utcnow() + timedelta(hours=3)
        )
            
        files = []
        converted_files = {}
        for directory_path in directory_paths:
            for blob in blob_list:
                if blob.name.startswith(directory_path):
                    if not blob.name.startswith(f'{directory_path}/converted/'):
                        files.append({
                            "filename" : blob.name,
                            # "directory_path": directory_path,
                            "converted": blob.metadata.get('converted', 'false') == 'true' if blob.metadata else False,
                            "embeddings_added": blob.metadata.get('embeddings_added', 'false') == 'true' if blob.metadata else False,
                            "fullpath": f"https://{self.account_name}.blob.core.windows.net/{self.file_system_name}/{blob.name}?{sas}",
                            "converted_filename": blob.metadata.get('converted_filename', '') if blob.metadata else '',
                            "converted_path": ""
                        })
                    else:
                        converted_files[blob.name] = f"https://{self.account_name}.blob.core.windows.net/{self.file_system_name}/{blob.name}?{sas}"

            for file in files:
                converted_filename = file.pop('converted_filename', '')
                if converted_filename in converted_files:
                    file['converted'] = True
                    file['converted_path'] = converted_files[converted_filename]
        
        return files

    def upsert_blob_metadata(self, file_name:str, metadata: dict):
        blob_client = BlobServiceClient.from_connection_string(self.connect_str).get_blob_client(container=f"{self.file_system_name}", blob=f"{file_name}")
        # Read metadata from the blob
        blob_metadata = blob_client.get_blob_properties().metadata
        # Update metadata
        blob_metadata.update(metadata)
        # Add metadata to the blob
        blob_client.set_blob_metadata(metadata= blob_metadata)

    def get_container_sas(self):
        # Generate a SAS URL to the file system and return it
        return "?" + generate_file_system_sas(
            account_name=self.account_name,
            file_system_name=self.file_system_name,
            credential=self.account_key,
            permission="r",
            expiry=datetime.utcnow() + timedelta(hours=3)
        )

    def get_blob_sas(self, file_path: str):
        # Generate a SAS URL to the blob and return it
        return f"https://{self.account_name}.blob.core.windows.net/{self.file_system_name}/{file_path}" + "?" + generate_blob_sas(account_name=self.account_name, container_name=self.file_system_name, blob_name=file_path, account_key=self.account_key, permission='r', expiry=datetime.utcnow() + timedelta(hours=1))
