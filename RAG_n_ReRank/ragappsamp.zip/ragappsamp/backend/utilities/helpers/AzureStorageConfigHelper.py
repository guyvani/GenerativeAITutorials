import logging

from typing import Optional, Union
from .EnvHelper import EnvHelper

from .AzureBlobStorageHelper import AzureBlobStorageClient
from .AzureDataLakeStorageHelper import AzureDataLakeStorageClient

class AzureStorageConfigClient:
    def __init__(self, account_type: Optional[str] = None):
        
        env_helper: EnvHelper = EnvHelper()
        
        self.account_type = account_type if account_type else env_helper.AZURE_STORAGE_ACCOUNT_TYPE
        
    def get_storage_account_helper(self) -> Union[AzureBlobStorageClient, AzureDataLakeStorageClient]:
        if self.account_type == 'blob':
            return AzureBlobStorageClient()
        elif self.account_type == 'datalake':
            return AzureDataLakeStorageClient()
        else:
            logging.error(f'Unsupported storage account type: {self.account_type}')
            logging.error('Use "blob" or "datalake" for storage account type')