import logging
from typing import List, Optional
from ..helpers.AzureSearchHelper import AzureSearchHelper
from ..helpers.LLMHelper import LLMHelper
from concurrent.futures import ThreadPoolExecutor
from langchain_core.documents import Document
from langchain.load import dumps, loads


# Setup basic configuration for logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class QueryRetriever:
    """
    Provides functionality for retrieving and processing queries using Azure Search and Langchain libraries.
    
    This class encapsulates methods for semantic search retrieval, query
    rephrasing, RAG fusion, and document reordering, using a combination of Azure Search and custom Langchain implementations
    """
    
    def __init__(self):
        """
        Initializes the QueryRetriever class with AzureSearchHelper and LLMHelper instances.
        """
        self.vector_store = AzureSearchHelper().get_vector_store()
        self.llm_helper = LLMHelper()
    
    def acs_retriever(self, k=10):
        """
        Creates an Azure Search retriever instance for semantic hybrid search.
        
        Parameters
        ----------
        k : int, optional
            The number of documents to retrieve, by default 10.
        
        Returns
        -------
        retriever
            An instance of Azure Search retriever configured for similarity search.
        
        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> azure_search_retriever = retriever_instance.acs_retriever(k=5)
        """
        try:
            retriever = self.vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})
            return retriever
        except Exception as e:
            logger.error(f"Failed to create Azure Search retriever: {e}")
            raise
    
    def base_retriever(self, query, k=10):
        """
        Retrieves documents based on the provided query using semantic hybrid search.
        
        Parameters
        ----------
        query : str
            The query string to search for.
        k : int, optional
            The number of documents to retrieve, by default 10.
        
        Returns
        -------
        list
            A list of documents retrieved based on the query.
        
        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> documents = retriever_instance.base_retriever("example query")
        """
        try:
            sources = self.vector_store.semantic_hybrid_search(query=query, k=k)
            return sources
        except Exception as e:
            logger.error(f"Failed to retrieve documents for query '{query}': {e}")
            return []
    
    def generate_prompt(self):
        """
        Generates a list of prompt templates for query rephrasing experiments.
        
        Returns
        -------
        list
            A list containing different prompt templates.
        
        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> prompts = retriever_instance.generate_prompt()
        """
        default_prompt = "You are a helpful assistant that rewrites a question to better formulate it based on a single input query."
        
        one_shot_learning_prompt = "You are a helpful assistant that rewrites a question to better formulate it based on a single input query.\
                                    For example, if a user provides a query like 'cost of IPR rider', you must rephrase it into a question like \
                                    'How much does an IPR rider cost?'. Another example is if a user provides a query like 'rates on the Secure \
                                    Term Choice Fixed Annuity', you must rephrase it into 'What are the rates for the Secure Term Choice Fixed Annuity?'"
        return [default_prompt, one_shot_learning_prompt]
    
    
    def rephrase_query(self, original_query, number_of_generated_queries=1, prompt_type=0, output_format='list'):
        """
        Rephrases the given query using a selected prompt and returns the rephrased query in the specified format.
        
        Parameters
        ----------
        original_query : str
            The original query to be rephrased.
        number_of_generated_queries : int, optional
            The number of rephrased queries to generate, by default 1.
        prompt_type : int, optional
            The index of the prompt template to use, by default 0.
        output_format : str, optional
            The format of the rephrased query output, either 'list' or 'string', by default 'list'.
        
        Returns
        -------
        str or list
            The rephrased query or queries in the specified output format.
        
        Raises
        ------
        ValueError
            If an invalid output_format is specified.
        
        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> rephrased_query = retriever_instance.rephrase_query("example query", prompt_type=1)
        """
        try:
            list_of_prompts = self.generate_prompt()
            if prompt_type >= len(list_of_prompts):
                raise IndexError("Prompt type index out of range.")
            query_generation_prompt = list_of_prompts[prompt_type]
            
            messages = [{"role": "system", "content": query_generation_prompt},
                        {"role": "user", "content": f"Generate multiple search queries related to: {original_query}"},
                        {"role": "user", "content": f"OUTPUT ({number_of_generated_queries} queries):"}]
            
            response = self.llm_helper.get_chat_completion(messages)
            rephrased_query = response.choices[0]["message"]["content"].strip().split("\n")
            
            if output_format == 'string':
                return ' '.join(rephrased_query)
            elif output_format == 'list':
                return rephrased_query
            else:
                raise ValueError("Invalid output format specified.")
        except Exception as e:
            logger.error(f"Error during query rephrasing: {e}")
            if output_format == 'list':
                return []
            else:
                return ""
    
    
    
    def rephrased_query_retriever(self, query, k=10):
        """
        Retrieves documents based on a rephrased version of the input query, using semantic hybrid search.

        Parameters
        ----------
        query : str
            The query to be rephrased and used for retrieval.
        k : int, optional
            The number of documents to retrieve, by default 10.

        Returns
        -------
        list
            A list of documents retrieved using the rephrased query.

        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> documents = retriever_instance.rephrased_query_retriever("example query")
        """
        try:
            # Rephrase the query for improved retrieval
            rephrased_query = self.rephrase_query(query, number_of_generated_queries=4, prompt_type=1)
            # Retrieve sources using the rephrased query
            sources = self.vector_store.semantic_hybrid_search(query=rephrased_query, k=k)
            return sources
        except Exception as e:
            logger.error(f"Failed to retrieve documents using a rephrased query: {e}")
            return []
        
        
        
    def _reciprocal_rank_fusion(self, results, k, m=60):
        """
        Applies reciprocal rank fusion to aggregate results from multiple lists of documents.

        Parameters
        ----------
        results : list of list
            A list containing lists of ranked documents.
        k : int
            The number of top documents to return after fusion.
        m : int, optional
            A parameter to control the influence of document ranks outliers, by default 60.

        Returns
        -------
        list
            A list of documents after applying reciprocal rank fusion, ordered by their fused scores.

        Notes
        -----
        This method assumes that each list in `results` contains documents ordered by relevance.
        """
        try:        
            fused_scores = {}
            for docs in results:
                for rank, doc in enumerate(docs):
                    doc_str = dumps(doc)
                    if doc_str not in fused_scores:
                        fused_scores[doc_str] = 0
                    #previous_score = fused_scores[doc_str]
                    fused_scores[doc_str] += 1 / (rank + m)

            reranked_results = [
                loads(doc)
                for doc, score in sorted(fused_scores.items(), key=lambda x: x[1], reverse=True)
            ]
            return reranked_results[:k]
        except Exception as e:
            logger.error(f"Error during reciprocal rank fusion: {e}")
            return []
        
        
    def rank_fusion_retriever(self, query, k, num_gen_queries, prompt_num):
        """
        Retrieves documents for a query and applies rank fusion for improved retrieval performance.

        Parameters
        ----------
        query : str
            The query for which documents are retrieved.
        k : int
            The number of documents to retrieve and fuse.
        num_gen_queries : int
            The number of queries to generate for rank fusion.
        prompt_num : int
            The prompt number to use for generating rephrased queries.

        Returns
        -------
        list
            A list of documents after rank fusion, potentially improving retrieval relevance.

        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> fused_documents = retriever_instance.rank_fusion_retriever("example query", 10, 5, 0)
        """
        try:
            # Prefill some parameters in the rephrase_query_filled function
            def rephrase_query_filled(original_query):
                return self.rephrase_query(original_query=original_query, number_of_generated_queries=num_gen_queries, prompt_type=prompt_num)
            
            # Prefill some parameters in the _reciprocal_rank_fusion function
            def reciprocal_rank_fusion_filled(results):
                return self._reciprocal_rank_fusion(results=results, k=k)   
            
            # Creating a chain of functions for query retrieval and rank fusion
            chain = rephrase_query_filled | self.acs_retriever(k=k).map() | reciprocal_rank_fusion_filled
            # Invoking the chain with the original query
            return chain.invoke({"original_query": query})
        
        except Exception as e:
            logger.error(f"Failed to perform rank fusion retrieval: {e}")
            return []    
        
        
        
    def long_context_reorder_documents(self, documents):
        """
        Reorders documents to mitigate the 'Lost in the Middle' problem, enhancing visibility of relevant documents.

        Parameters
        ----------
        documents : List[Document]
            A list of Document objects to reorder.

        Returns
        -------
        List[Document]
            The reordered list of documents.

        Raises
        ------
        ValueError
            If the input is not a list of Document objects.

        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> ordered_documents = retriever_instance.long_context_reorder_documents(documents)
        """
        if not all(isinstance(doc, Document) for doc in documents):
            raise ValueError("All items in `documents` must be instances of Document.")

        try:
            # Implementing 'Lost in the Middle' reordering strategy
            documents_copy = documents[::-1]  # Reverse the list by slicing
            reordered_result = []
            for i, document in enumerate(documents_copy):
                if i % 2 == 0:
                    reordered_result.insert(0, document)
                else:
                    reordered_result.append(document)
            return reordered_result
        except Exception as e:
            logger.error(f"Failed to reorder documents: {e}")
            raise  
        


    def long_context_retriever(self, query, k, is_search_semantic=False):
        """
        Retrieves documents for a query and reorders them to optimize for long context processing.

        Parameters
        ----------
        query : str
            The query string.
        k : int
            The number of documents to retrieve.
        is_search_semantic : bool, optional
            Whether to use semantic search, by default False.

        Returns
        -------
        List[Document]
            A list of reordered documents based on the given query.

        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> reordered_docs = retriever_instance.long_context_retriever("example query", 10, True)
        """
        try:
            if is_search_semantic:
                docs = self.base_retriever(query, k)
            else:
                docs = self.acs_retriever(k).get_relevant_documents(query)
            reordered_docs = self.long_context_reorder_documents(docs)
            return reordered_docs
        except Exception as e:
            logger.error(f"Failed to retrieve or reorder documents for long context processing: {e}")
            return [] 
        


    def long_context_rank_fusion_retriever(self, query, k, num_gen_queries, prompt_num):
        """
        Retrieves and reorders documents using rank fusion and long context optimization techniques.

        Parameters
        ----------
        query : str
            The query for which documents are retrieved.
        k : int
            The number of documents to retrieve and reorder.
        num_gen_queries : int
            The number of generated queries for rank fusion.
        prompt_num : int
            The index of the prompt to use for query generation.

        Returns
        -------
        List[Document]
            A list of documents reordered to enhance long context comprehension.

        Examples
        --------
        >>> retriever_instance = QueryRetriever()
        >>> optimized_docs = retriever_instance.long_context_rank_fusion_retriever("example query", 10, 5, 1)
        """
        try:
            fused_docs = self.rank_fusion_retriever(query, k, num_gen_queries, prompt_num)
            reordered_docs = self.long_context_reorder_documents(fused_docs)
            return reordered_docs
        except Exception as e:
            logger.error(f"Failed to retrieve, RAG fusion, and reorder documents: {e}")
            return []