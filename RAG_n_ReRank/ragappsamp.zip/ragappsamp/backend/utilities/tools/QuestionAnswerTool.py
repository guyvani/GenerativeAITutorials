from typing import List
from .AnsweringToolBase import AnsweringToolBase

from langchain.chains.llm import LLMChain
from langchain.prompts import PromptTemplate
from langchain.callbacks import get_openai_callback

from ..helpers.AzureSearchHelper import AzureSearchHelper
from ..helpers.ConfigHelper import ConfigHelper
from ..helpers.LLMHelper import LLMHelper
from ..common.Answer import Answer
from ..common.SourceDocument import SourceDocument

#from tools.RetrieversTool import base_retriever, rephrased_query_retriever

from .RetrieversTool import QueryRetriever

query_prompt_template = """Below is a history of the conversation so far, and a new question asked by the user that needs to be answered by searching in a knowledge base about customer service professional procedures
You have access to Azure Cognitive Search index with 100's of documents.
Generate a search query based on the conversation and the new question. The search uses a mixture of keyword, vector and semantic search.
Please generate a search query which is optimized for finding the relevant documents to answer the question. Respond in only a text response. Your output will be passed as a string. Do not include "" or any non letter values.


History: {history_str}
User's Question: {question}
Optimized Search Query:
"""

detailed_system_prompt = """

You are an AI assistant that helps New York Life customer service representatives on how they can advise clients with their questions. You should give guidance to the customer service representative on how they can use the information in the documents to guide the client through next steps.

The context is structured like this:

[docX]:  <content>
<and more of them>

When you give your answer, you ALWAYS MUST include one or more of the above sources in your response in the following format: <answer> [docX]
Always use square brackets to reference the document source. When you create the answer from multiple sources, list each source separately, e.g. <answer> [docX][docY] and so on.
Ensure your citation is using the valid numerical value from the context: sources below so [doc1] etc.
Always reply in the language of the question.

Only discuss topics which are relevant to questions related to New York Life Insurance Company Customer Service procedures, documentation and financial products. If there is a question about other content reply simply with "As Service Sage, I can only assist with New York Life Customer Service Related Questions."


Context:
{sources}

Please reply to the question using only the information Context section above. If you can't answer a question using the context, reply politely that the information is not in the knowledge base. DO NOT make up your own answers. You detect the language of the question and answer in the same language.  If asked for enumerations list all of them and do not invent any.
You should provide longer and detailed answers which attempt to explain how to perform an action. You should justify your responses. You should also format your answers step by step or in list fashion, so it is easier to read.

Chat History: {history_str}
Answer:"""

concise_system_prompt = """

You are an AI assistant that helps New York Life customer service representatives on how they can advise clients with their questions. You should give guidance to the customer service representative on how they can use the information in the documents to guide the client through next steps. Your answers all answer clearly and accurately and avoid making them too lengthy. Ensure accuracy and nuance in your responses you can provide some justification.

The context is structured like this:

[docX]:  <content>
<and more of them>

When you give your answer, you ALWAYS MUST include one or more of the above sources in your response in the following format: <answer> [docX]
Always use square brackets to reference the document source. When you create the answer from multiple sources, list each source separately, e.g. <answer> [docX][docY] and so on.
Ensure your citation is using the valid numerical value from the context: sources below so [doc1] etc.
Always reply in the language of the question.

Only discuss topics which are relevant to questions related to New York Life Insurance Company Customer Service procedures, documentation and financial products. If there is a question about other content reply simply with "As Service Sage, I can only assist with New York Life Customer Service Related Questions."


Context:
{sources}

Please reply to the question using only the information Context section above. If you can't answer a question using the context, reply politely that the information is not in the knowledge base. DO NOT make up your own answers. You detect the language of the question and answer in the same language.  If asked for enumerations list all of them and do not invent any.


Chat History: {history_str}
Answer:"""


class QuestionAnswerTool(AnsweringToolBase):
    def __init__(self) -> None:
        self.name = "QuestionAnswer"
        self.vector_store = AzureSearchHelper().get_vector_store()
        self.verbose = True
        self.Retriever = QueryRetriever()

    def answer_question(
        self,
        question: str,
        chat_history: List[dict],
        messages: List[dict[str, str]],
        prompt_style: str,
        **kwargs: dict,
    ):
        config = ConfigHelper.get_active_config_or_default()

        active_prompt = """"""
        if prompt_style == "detailed":
            active_prompt = detailed_system_prompt
        else:
            active_prompt = concise_system_prompt

        answering_prompt = PromptTemplate(
            template=active_prompt, input_variables=["sources", "history_str"]
        )

        query_history_prompt = PromptTemplate(
            template=query_prompt_template,
            input_variables=["history_str", "question"],
        )

        llm_helper = LLMHelper()

        formatted_messages = []

        for message in messages:
            role = message[
                "role"
            ].capitalize()  # Make the first letter uppercase
            if role == "System":
                continue
            content = message["content"]
            formatted_messages.append(f"{role}: {content}")

        history_str = "\n".join(formatted_messages)

        print(history_str)

        direct_user_query = messages[-1]["content"]

        optimized_search_hist = LLMChain(
            llm=llm_helper.get_llm(),
            prompt=query_history_prompt,
            verbose=self.verbose,
        )
        acs_query = optimized_search_hist(
            {"history_str": direct_user_query, "question": question}
        )
        processed_acs_query = acs_query["text"]
        print(processed_acs_query)

        # Retrieve documents as sources
        
        #baseline retriever
        #sources = self.Retriever.base_retriever(query=processed_acs_query, k=10)
        
        # Combination RAG Fusion and Long Context Reorder Retriever
        sources = self.Retriever.long_context_rank_fusion_retriever(query=processed_acs_query, k=10, num_gen_queries=2, prompt_num=1)
        

        # Generate answer from sources
        answer_generator = LLMChain(
            llm=llm_helper.get_llm(),
            prompt=answering_prompt,
            verbose=self.verbose,
        )
        sources_text = "\n\n".join(
            [
                f"[doc{i+1}]: {source.page_content}"
                for i, source in enumerate(sources)
            ]
        )

        with get_openai_callback() as cb:
            result = answer_generator(
                {"sources": sources_text, "history_str": history_str}
            )

        answer = result["text"]
        print(f"Answer: {answer}")

        # Generate Answer Object
        source_documents = []
        for source in sources:
            source_document = SourceDocument(
                id=source.metadata["id"],
                content=source.page_content,
                title=source.metadata["title"],
                source=source.metadata["source"],
                chunk=source.metadata["chunk"],
                offset=source.metadata["offset"],
                page_number=source.metadata["page_number"],
            )
            source_documents.append(source_document)

        clean_answer = Answer(
            question=question,
            answer=answer,
            source_documents=source_documents,
            prompt_tokens=cb.prompt_tokens,
            completion_tokens=cb.completion_tokens,
        )
        return clean_answer
