<br/>
<div align ="center">
  <img src="./frontend/src/assets/service_sage.png" height="100">
  <h1>Service Sage
</div>

[Service Sage](https://pilot.servicesage.newyorklife.com) is a Generative AI chat application designed to customer service representatives search through procedure documents (currently, payments and disbursments). This repository contains the source code for the frontend, backend and data ingestion processes.

## RAG Flow Diagram

<div align="center">
  <img src="./images/RAG Flow Diagram.png">
</div>

## Frontend Structure Overview

- [`src`](/frontend/src): This directory is the heart of the frontend application, housing the core code that powers your user interface.

  - [`api`](/frontend/src/api/): Contains all the API integration logic, ensuring seamless communication with backend services and external APIs. This is where we encapsulate the intricacies of network requests and responses.

  - [`components`](/frontend/src/components/): A collection of reusable UI components such as buttons, input fields, and modals. These components are the building blocks of our application's interface, designed for modularity and reusability.

  - [`constants`](/frontend/src/constants/): Here we define the application-wide constants. This includes configuration values, enums, and any other constant data that provides consistency across the application.

  - [`pages`](/frontend/src/pages/): Dedicated to the various pages of our application. Each file or folder in this section represents a different view or route, structuring the overall user journey within our application.

  - [`state`](/frontend/src/state/): Manages the application's global state. Utilizing modern state management techniques, this area ensures responsive and efficient data flow across the application.

  - [`stories`](/frontend/src/stories/): This directory hosts our Storybook stories, serving as a living documentation for UI components. It's a playground for visual testing and a showcase of our components in various states.

  - [`utilities`](/frontend/src/utilities/): A suite of utility functions and helpers that provide common functionality across the application. Currently it only holds one function, but can be expanded for future frontend utilities.

## Backend Structure Overview

### Azure Serverless Functions

- [`AddURLEmbeddings`](/backend/AddURLEmbeddings/): HTTP trigger function with URL using custom document processing logic and return an appropriate HTTP response based on the outcome of processing.

- [`BatchPushResults`](/backend/BatchPushResults/): Azure Functions queue trigger function, triggered by messages in Azure Queue Storage. Processes the files using `DocumentProcessor`.

- [`BatchStartProcessing`](/backend/BatchStartProcessing/): Azure Queue Trigger function that processes files specified in queue messages. It retrieves the file path from the message, generates a secure URL for the file, processes it using custom document processors, and then updates the file's metadata in Azure Storage to indicate processing completion.

### API / Admin Pages

- [`app.py`](/app.py): Flask entry server run script. Contains the definition of the API routes for chat history, chat generation and feedback.

- [`auth`](/backend/auth/): Here are the utilities needed to handle authentication for the Azure Web App Service. We are using OpenID Connect with Azure's EasyAuth.

- [`history`](/backend/history/): Contains some of the functions needed to support CRUD operations in Azure CosmosDB. Referenced to handle Chat History storage operations.

- [`pages`](/backend/pages/): This holds the Admin Site pages for orchestrating data ingestion Azure Functions. These are [Streamlit](https://streamlit.io) files which are subpages from the main `Admin.py` file.

### GenAI Methods and Utilities

- [`utilities`](/backend/utilities/): The root folder which holds many of the methods needed for Chat Generation and RAG QnA.

  - [`common`](/backend/utilities/common/): Contains shared classes including the data schemes for the `Answer` and `SourceDocument` objects.

  - [`document_chunking`](/backend/utilities/document_chunking/): This directory holds the various chunking methodologies which are supported by the application. `FixedSizeOverlap`, `Layout`, `Page`, `Paragraph`

  - [`document_loading`](/backend/utilities/document_loading/): Holds the different ways of loading in the source documents. This allows for reading PDF, DOCX and how to process using Azure Document Intelligence.

  - [`helpers`](/backend/utilities/helpers/): A series of helper files which abstract some of the complicated details of connecting to Azure Resources and Environment setup.

  - [`loggers`](/backend/utilities/loggers/): Logging functions which keep track of conversation logging and token information for chats.

  - [`orchestrator`](/backend/utilities/orchestrator/): This holds two main ways of orchestrating the LLMs for RAG. Using OpenAI Function calling (`OpenAIFunctions.py`) and using LangChain Agent modules (`LangChainAgent.py`). Pilot currently uses OpenAI Function calling.

  - [`parser`](/backend/utilities/parser/): Contains a parsing utility which prepares the AI model response for display in the user interface. Particularly, it prepares the citations and document links from the AI text response.

  - [`tests`](/backend/utilities/tests): Files for testing some of the functions needed for document chunking, loading, and RAG orchestrating.

  - [`tools`](/backend/utilities/tools): A series of tool functions which are provided to the LLM to invoke. This allows the LLM to call the Azure AI Search DB, generate natural langauge replies and other text processing methods.
