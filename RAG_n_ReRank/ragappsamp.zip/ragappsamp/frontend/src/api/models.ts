export type AskResponse = {
  answer: string;
  answerId?: string;
  question?: string | undefined;
  citations: Citation[];
  error?: string;
  feedback?: Feedback;
};

export type Citation = {
  content: string;
  id: string;
  title: string | null;
  filepath: string | null;
  url: string | null;
  metadata: string | null;
  chunk_id: string | null;
  reindex_id: string | null;
};

export type ToolMessageContent = {
  citations: Citation[];
  intent: string;
};

export type ChatMessage = {
  id?: string;
  role: string;
  content: string;
  end_turn?: boolean;
  date?: string;
  feedback?: Feedback;
};

export enum ChatCompletionType {
  ChatCompletion = "chat.completion",
  ChatCompletionChunk = "chat.completion.chunk",
}

export type ChatResponseChoice = {
  messages: ChatMessage[];
};

export type ChatResponse = {
  id: string;
  model: string;
  created: number;
  object: ChatCompletionType;
  choices: ChatResponseChoice[];
  history_metadata: {
    conversation_id: string;
    title: string;
    date: string;
  };
  error?: any;
};

export type ConversationRequest = {
  id?: string;
  messages: ChatMessage[];
};

export type UserInfo = {
  access_token: string;
  expires_on: string;
  id_token: string;
  provider_name: string;
  user_claims: any[];
  user_id: string;
};

export enum CosmosDBStatus {
  NotConfigured = "CosmosDB is not configured",
  NotWorking = "CosmosDB is not working",
  Working = "CosmosDB is configured and working",
}

export type CosmosDBHealth = {
  cosmosDB: boolean;
  status: string;
};

export enum ChatHistoryLoadingState {
  Loading = "loading",
  Success = "success",
  Fail = "fail",
  NotStarted = "notStarted",
}

export type ErrorMessage = {
  title: string;
  subtitle: string;
};

export type Conversation = {
  id: string | undefined;
  title: string;
  messages: ChatMessage[];
  date: string;
};

export type Feedback = {
  messageId?: string;
  stars: number;
  comment?: string;
  feedbackType?: string;
};

export type UpdatedMessage = {
  id: string;
  content: string;
  role: string;
  type: string;
  updatedAt: string;
  createdAt: string;
};
