import {
	ChatHistoryLoadingState,
	ChatMessage,
	ChatResponse,
	Citation,
	Conversation,
	CosmosDBHealth,
	CosmosDBStatus,
	Feedback,
	UserInfo,
} from '../api/models';

export interface AppState {
	isChatHistoryOpen: boolean;
	chatHistoryLoadingState: ChatHistoryLoadingState;
	isCosmosDBAvailable: CosmosDBHealth;
	chatHistory: Conversation[] | null;
	filteredChatHistory: Conversation[] | null;
	currentChat: Conversation | null;
	isConversationStarted: boolean;
	citation: Citation | null;
	promptStyle: 'fast' | 'detailed';
	userInfo: UserInfo | null;
	// errors: string [];
	// warnings: string []
}

export const initialState: AppState = {
	isChatHistoryOpen: false,
	chatHistoryLoadingState: ChatHistoryLoadingState.Loading,
	chatHistory: null,
	filteredChatHistory: null,
	currentChat: {
		id: undefined,
		date: '',
		messages: [],
		title: '',
	},
	isCosmosDBAvailable: {
		cosmosDB: false,
		status: CosmosDBStatus.NotConfigured,
	},
	isConversationStarted: false,
	citation: null,
	promptStyle: 'fast',
	userInfo: null,
};

export type Action =
	| { type: 'SET_COSMOSDB_STATUS'; payload: CosmosDBHealth }
	| {
			type: 'UPDATE_CHAT_HISTORY_LOADING_STATE';
			payload: ChatHistoryLoadingState;
		}
	| { type: 'TOGGLE_PROMPT_STYLE' }
	// Conversation
	| { type: 'NEW_CHAT' }
	| { type: 'QUESTION_ASKED'; payload: ChatMessage }
	| { type: 'RESPONSE_RECEIVED'; payload: ChatResponse }
	| { type: 'CHAT_ERROR'; payload: ChatMessage }
	| { type: 'UPDATE_FILTERED_CHAT_HISTORY'; payload: Conversation[] | null }
	// Chat History Actions
	| { type: 'TOGGLE_CHAT_HISTORY' }
	| { type: 'FETCH_CHAT_HISTORY'; payload: Conversation[] | null } // API Call
	| { type: 'UPDATE_CHAT_TITLE'; payload: Conversation } // API Call
	| { type: 'DELETE_CHAT_ENTRY'; payload: string } // API Call
	| { type: 'DELETE_CHAT_HISTORY' } // API Call
	| { type: 'DELETE_CURRENT_CHAT_MESSAGES'; payload: string } // API Call
	| { type: 'UPDATE_CURRENT_CHAT'; payload: Conversation }
	//  Citations
	| { type: 'OPEN_CITATION'; payload: Citation }
	| { type: 'CLOSE_CITATION' }
	| { type: 'USER_INFO_RECEIVED'; payload: UserInfo }
	| { type: 'FEEDBACK_PROVIDED'; payload: Feedback };