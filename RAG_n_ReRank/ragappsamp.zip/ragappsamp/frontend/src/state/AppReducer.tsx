import { Action, AppState } from './models';

// Define the reducer function
export const AppStateReducer = (state: AppState, action: Action): AppState => {
  switch (action.type) {
    case 'TOGGLE_PROMPT_STYLE':
      return {
        ...state,
        promptStyle: state.promptStyle == 'detailed' ? 'fast' : 'detailed',
      };

    case 'TOGGLE_CHAT_HISTORY':
      return { ...state, isChatHistoryOpen: !state.isChatHistoryOpen };

    case 'QUESTION_ASKED':
      if (!state.currentChat!.messages.includes(action.payload)) {
        state.currentChat!.messages.push(action.payload);
      }
      return {
        ...state,
        isConversationStarted: true,
      };

    case 'RESPONSE_RECEIVED': {
      const history = action.payload.history_metadata;
      const messages = action.payload.choices[0].messages;

      const currentChat = {
        date: history.date ?? state.currentChat!.date,
        id: state.currentChat!.id ?? history.conversation_id,
        messages: state.currentChat!.messages.concat(messages),
        title: history.title ?? state.currentChat!.title,
      };

      if (state.chatHistory != null) {
        const conversationIndex = state.chatHistory.findIndex(
          (conv) => conv.id === history.conversation_id
        );

        if (conversationIndex !== -1) {
          state.chatHistory[conversationIndex] = currentChat;
        } else {
          state.chatHistory = [...state.chatHistory, currentChat];
        }
      }

      return {
        ...state,
        currentChat,
      };
    }

    case 'CHAT_ERROR': {
      const errorMessage = action.payload;
      return {
        ...state,
        currentChat: {
          ...state.currentChat!,
          messages: state.currentChat!.messages.concat(errorMessage),
        },
      };
    }

    case 'UPDATE_CHAT_HISTORY_LOADING_STATE':
      return { ...state, chatHistoryLoadingState: action.payload };

    case 'UPDATE_CHAT_TITLE': {
      if (!state.chatHistory) {
        return { ...state, chatHistory: [] };
      }
      const updatedChats = state.chatHistory.map((chat) => {
        if (chat.id === action.payload.id) {
          if (state.currentChat?.id === action.payload.id) {
            state.currentChat!.title = action.payload.title;
          }
          //TODO: make api call to save new title to DB
          return { ...chat, title: action.payload.title };
        }
        return chat;
      });
      return { ...state, chatHistory: updatedChats };
    }

    case 'DELETE_CHAT_ENTRY': {
      if (!state.chatHistory) {
        return { ...state, chatHistory: [] };
      }
      const filteredChat = state.chatHistory.filter(
        (chat) => chat.id !== action.payload
      );
      state.currentChat = {
        id: undefined,
        date: '',
        messages: [],
        title: '',
      };
      //TODO: make api call to delete conversation from DB
      return { ...state, chatHistory: filteredChat };
    }

    case 'DELETE_CHAT_HISTORY':
      //TODO: make api call to delete all conversations from DB
      return {
        ...state,
        chatHistory: [],
        filteredChatHistory: [],
        currentChat: {
          id: undefined,
          date: '',
          messages: [],
          title: '',
        },
      };

    case 'DELETE_CURRENT_CHAT_MESSAGES': {
      //TODO: make api call to delete current conversation messages from DB
      if (!state.currentChat || !state.chatHistory) {
        return state;
      }
      // eslint-disable-next-line no-case-declarations
      const updatedCurrentChat = {
        ...state.currentChat,
        messages: [],
      };
      return {
        ...state,
        currentChat: updatedCurrentChat,
      };
    }

    case 'FETCH_CHAT_HISTORY':
      return { ...state, chatHistory: action.payload };

    case 'SET_COSMOSDB_STATUS':
      return { ...state, isCosmosDBAvailable: action.payload };

    case 'OPEN_CITATION':
      return { ...state, citation: action.payload };

    case 'CLOSE_CITATION':
      return { ...state, citation: null };

    case 'NEW_CHAT':
      return {
        ...state,
        isConversationStarted: false,
        citation: null,
        currentChat: {
          id: undefined,
          date: '',
          messages: [],
          title: '',
        },
      };

    case 'UPDATE_CURRENT_CHAT':
      return {
        ...state,
        isConversationStarted: true,
        citation: null,
        currentChat: {
          ...action.payload,
        },
      };

    case 'USER_INFO_RECEIVED':
      return {
        ...state,
        userInfo: {
          ...action.payload,
        },
      };

    case 'FEEDBACK_PROVIDED': {
      const currentChat = state.currentChat;
      const feedback = action.payload;

      const message = currentChat?.messages.find(
        (m) => m.id == feedback.messageId
      );
      message!.feedback = feedback;

      if (state.chatHistory) {
        const chatHistory = state.chatHistory;
        const conversation = chatHistory.find((c) => c.id == currentChat?.id);
        const conversationMessage = conversation?.messages.find(
          (m) => m.id == feedback.messageId
        );

        conversationMessage!.feedback = feedback;

        return {
          ...state,
          ...currentChat,
          ...chatHistory,
        };
      }

      return {
        ...state,
        ...currentChat,
      };
    }

    default:
      return state;
  }
};
