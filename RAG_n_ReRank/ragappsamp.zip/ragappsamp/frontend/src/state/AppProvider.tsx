import React, {
    createContext,
    useReducer,
    ReactNode,
    useEffect,
    useContext,
    Dispatch,
} from 'react';
import { AppStateReducer } from './AppReducer';
import {
	ChatHistoryLoadingState,
	historyList,
	historyEnsure,
	CosmosDBStatus,
	getUserInfo,
	UserInfo,
} from '../api';
import { Conversation } from '../api';
import { Action, AppState, initialState } from './models';

const AppStateContext = createContext<AppState>(initialState);
const AppDispatchContext = createContext<Dispatch<Action>>(() => null);

type AppStateProviderProps = {
	children: ReactNode;
};

export const AppStateProvider: React.FC<AppStateProviderProps> = ({
	children,
}) => {
	const [appState, dispatch] = useReducer(AppStateReducer, initialState);

	useEffect(() => {
		// Check for cosmosdb config and fetch initial data here
		const fetchChatHistory = async (): Promise<Conversation[] | null> => {
			const result = await historyList()
				.then((response) => {
					if (response) {
						dispatch({ type: 'FETCH_CHAT_HISTORY', payload: response });
					} else {
						dispatch({ type: 'FETCH_CHAT_HISTORY', payload: null });
					}
					return response;
				})
				.catch(() => {
					dispatch({
						type: 'UPDATE_CHAT_HISTORY_LOADING_STATE',
						payload: ChatHistoryLoadingState.Fail,
					});
					dispatch({ type: 'FETCH_CHAT_HISTORY', payload: null });
					console.error('There was an issue fetching your data.');
					return null;
				});
			return result;
		};

		const getHistoryEnsure = async () => {
			dispatch({
				type: 'UPDATE_CHAT_HISTORY_LOADING_STATE',
				payload: ChatHistoryLoadingState.Loading,
			});
			historyEnsure()
				.then((response) => {
					if (response?.cosmosDB) {
						fetchChatHistory()
							.then((res) => {
								if (res) {
									dispatch({
										type: 'UPDATE_CHAT_HISTORY_LOADING_STATE',
										payload: ChatHistoryLoadingState.Success,
									});
									dispatch({ type: 'SET_COSMOSDB_STATUS', payload: response });
								} else {
									dispatch({
										type: 'UPDATE_CHAT_HISTORY_LOADING_STATE',
										payload: ChatHistoryLoadingState.Fail,
									});
									dispatch({
										type: 'SET_COSMOSDB_STATUS',
										payload: {
											cosmosDB: false,
											status: CosmosDBStatus.NotWorking,
										},
									});
								}
							})
							.catch(() => {
								dispatch({
									type: 'UPDATE_CHAT_HISTORY_LOADING_STATE',
									payload: ChatHistoryLoadingState.Fail,
								});
								dispatch({
									type: 'SET_COSMOSDB_STATUS',
									payload: {
										cosmosDB: false,
										status: CosmosDBStatus.NotWorking,
									},
								});
							});
					} else {
						dispatch({
							type: 'UPDATE_CHAT_HISTORY_LOADING_STATE',
							payload: ChatHistoryLoadingState.Fail,
						});
						dispatch({ type: 'SET_COSMOSDB_STATUS', payload: response });
					}
				})
				.catch(() => {
					dispatch({
						type: 'UPDATE_CHAT_HISTORY_LOADING_STATE',
						payload: ChatHistoryLoadingState.Fail,
					});
					dispatch({
						type: 'SET_COSMOSDB_STATUS',
						payload: { cosmosDB: false, status: CosmosDBStatus.NotConfigured },
					});
				});
		};
		getHistoryEnsure();
	}, []);

	useEffect(() => {
		getUserInfo().then((response: UserInfo[]) => {
			dispatch({
				type: 'USER_INFO_RECEIVED',
				payload: response[0],
			});
		});
	}, []);

	return (
		<AppStateContext.Provider value={appState}>
			<AppDispatchContext.Provider value={dispatch}>
				{children}
			</AppDispatchContext.Provider>
		</AppStateContext.Provider>
	);
};

export const useAppState = () => useContext(AppStateContext);
export const useAppDispatch = () => useContext(AppDispatchContext);
