import { Outlet, Link } from "react-router-dom";
import styles from "./Layout.module.css";
import NylLogo from "../../assets/NylLogo.svg";
import ServiceSageLogo from "../../assets/service_sage.png";
// import { CopyRegular, ShareRegular } from "@fluentui/react-icons";
import { Dialog, Stack, TextField } from "@fluentui/react";
import PromptToggle from "../../components/PromptToggle/PromptToggle";

import { useContext, useEffect, useState } from "react";
import { HistoryButton, ShareButton } from "../../components/common/Button";
import { useAppDispatch, useAppState } from "../../state/AppProvider";
import { CosmosDBStatus } from "../../api";

const Layout = ({
  setPromptStyle,
}: {
  setPromptStyle: React.Dispatch<React.SetStateAction<string>>;
}) => {
  // const [isSharePanelOpen, setIsSharePanelOpen] = useState<boolean>(false);
  const [isSharePanelOpen, setIsSharePanelOpen] = useState<boolean>(false);
  const [copyClicked, setCopyClicked] = useState<boolean>(false);
  const [copyText, setCopyText] = useState<string>("Copy URL");
  const appState = useAppState();
  const dispatch = useAppDispatch();

  const handleShareClick = () => {
    setIsSharePanelOpen(true);
  };

  const handleSharePanelDismiss = () => {
    setIsSharePanelOpen(false);
    setCopyClicked(false);
    setCopyText("Copy URL");
  };

  const handleHistoryClick = () => {
    console.log(appState);
    dispatch({ type: "TOGGLE_CHAT_HISTORY" });
  };

  useEffect(() => {
    if (copyClicked) {
      setCopyText("Copied URL");
    }
  }, [copyClicked]);

  useEffect(() => {}, [appState?.isCosmosDBAvailable.status]);

  const handleCopyClick = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopyClicked(true);
  };
  return (
    <div className={styles.layout}>
      <header className={styles.header} role={"banner"}>
        <div className={styles.headerContainer}>
          <Stack
            horizontal
            verticalAlign="center"
            horizontalAlign="space-between"
            // className={styles.headerContainer}
          >
            <Stack horizontal verticalAlign="center">
              <img
                src={ServiceSageLogo}
                className={styles.headerIcon}
                aria-hidden="true"
              />
              <img
                src={NylLogo}
                className={styles.headerIcon}
                aria-hidden="true"
              />
              <Link to="/" className={styles.headerTitleContainer}>
                <h3 className={styles.headerTitle}>Service Sage</h3>
              </Link>
            </Stack>
            <Stack horizontal tokens={{ childrenGap: 4 }}>
              {appState?.isCosmosDBAvailable?.status !==
                CosmosDBStatus.NotConfigured && (
                <HistoryButton
                  onClick={handleHistoryClick}
                  text={
                    appState?.isChatHistoryOpen
                      ? "Hide chat history"
                      : "Show chat history"
                  }
                />
              )}
            </Stack>
          </Stack>
          <PromptToggle setParentPromptStyle={setPromptStyle} />
        </div>
      </header>
      <Outlet />
    </div>
  );
};

export default Layout;
