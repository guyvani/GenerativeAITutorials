import {
  useRef,
  useState,
  useEffect,
  // useLayoutEffect,
} from "react";

import {
  CommandBarButton,
  IconButton,
  Dialog,
  DialogType,
  Stack,
} from "@fluentui/react";

import { SquareRegular } from "@fluentui/react-icons";
import { ErrorCircleRegular } from "@fluentui/react-icons";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeRaw from "rehype-raw";
import { v4 as uuidv4 } from "uuid";
import uuid from "react-uuid";
import { ExampleQuestions } from "../../components/ExampleQuestions";
import styles from "./Chat.module.css";
import NylLogo from "../../assets/NylLogo.svg";
import ServiceSageLogo from "../../assets/service_sage.png";

import {
  ChatMessage,
  ConversationRequest,
  Citation,
  ToolMessageContent,
  ChatResponse,
} from "../../api";
import {
  historyGenerate,
  // historyUpdate,
  historyClear,
  ChatHistoryLoadingState,
  CosmosDBStatus,
  ErrorMessage,
  rateUserPrompt
} from "../../api";
import { Answer } from "../../components/Answer";
import { QuestionInput } from "../../components/QuestionInput";
import { ChatHistoryPanel } from "../../components/ChatHistory/ChatHistoryPanel";
import { useAppDispatch, useAppState } from "../../state/AppProvider";
import { useBoolean } from "@fluentui/react-hooks";
import React from 'react';

const promptScoreValues: {
  [key: string]: string
} = {
  0: "Waiting for prompt...",
  1: "Poor",
  2: "Average",
  3: "Needs details",
  4: "Good",
  5: "Excellent"
}

const Chat = ({ promptStyle }: { promptStyle: string }) => {
  const appState = useAppState();
  const dispatch = useAppDispatch();
  const lastQuestionRef = useRef<string>("");
  const chatMessageStreamEnd = useRef<HTMLDivElement | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showLoadingMessage, setShowLoadingMessage] = useState<boolean>(false);
  const [activeCitation, setActiveCitation] =
    useState<
      [
        content: string,
        id: string,
        title: string,
        filepath: string,
        url: string,
        metadata: string
      ]
    >();
  const [isCitationPanelOpen, setIsCitationPanelOpen] =
    useState<boolean>(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  // const [processMessages, setProcessMessages] = useState<messageStatus>(
  //   messageStatus.NotRunning
  // );
  const abortFuncs = useRef([] as AbortController[]);
  const [conversationId, setConversationId] = useState<string>(uuidv4());
  const [clearingChat, setClearingChat] = useState<boolean>(false);
  const [hideErrorDialog, { toggle: toggleErrorDialog }] = useBoolean(true);
  const [errorMsg, setErrorMsg] = useState<ErrorMessage | null>();
  const [userPromptScore, setUserPromptScore] = useState(0)

  const errorDialogContentProps = {
    type: DialogType.close,
    title: errorMsg?.title,
    closeButtonAriaLabel: "Close",
    subText: errorMsg?.subtitle,
  };

  const modalProps = {
    titleAriaId: "labelId",
    subtitleAriaId: "subTextId",
    isBlocking: true,
    styles: { main: { maxWidth: 450 } },
  };

  useEffect(() => {
    if (
      appState?.isCosmosDBAvailable?.status ===
        CosmosDBStatus.NotWorking &&
      appState.chatHistoryLoadingState ===
        ChatHistoryLoadingState.Fail &&
      hideErrorDialog
    ) {
      let subtitle = `${appState.isCosmosDBAvailable.status}. Please contact the site administrator.`;
      setErrorMsg({
        title: "Chat history is not enabled",
        subtitle: subtitle,
      });
      toggleErrorDialog();
    }
  }, [appState?.isCosmosDBAvailable]);

  const handleErrorDialogClose = () => {
    toggleErrorDialog();
    setTimeout(() => {
      setErrorMsg(null);
    }, 500);
  };

  const getQuestionInputScore = async (question: string) => {
    console.log(question)
    if (question.length>0 || question !== null){
      const response =  await rateUserPrompt(question)
      console.log(response)
      setUserPromptScore(response)
    } else {
      setUserPromptScore(0)
    }
  }

  const makeApiRequestWithCosmosDB = async (
    question: string,
    conversationId?: string
  ) => {
    lastQuestionRef.current = question;
    setUserPromptScore(0)
    setIsLoading(true);
    setShowLoadingMessage(true);
    const abortController = new AbortController();
    abortFuncs.current.unshift(abortController);

    const userMessage: ChatMessage = {
      id: uuid(),
      role: "user",
      content: question,
      date: new Date().toISOString(),
    };

    let request: ConversationRequest;
    let conversation;
    if (conversationId) {
      conversation = appState.chatHistory?.find(
        (conv) => conv.id === conversationId
      );
      if (!conversation) {
        console.error("Conversation not found.");
        setIsLoading(false);
        setShowLoadingMessage(false);
        abortFuncs.current = abortFuncs.current.filter(
          (a) => a !== abortController
        );
        return;
      } else {
        conversation.messages.push(userMessage);
        request = {
          messages: [
            ...conversation.messages.filter(
              (answer) => answer.role !== "error"
            ),
          ],
        };
      }
    } else {
      request = {
        messages: [userMessage].filter((answer) => answer.role !== "error"),
      };
      setMessages(request.messages);
    }
    let result = {} as ChatResponse;
    try {
      const response = conversationId
        ? await historyGenerate(
            request,
            abortController.signal,
            promptStyle,
            conversationId
          )
        : await historyGenerate(request, abortController.signal, promptStyle);
      if (!response?.ok) {
        console.log(response.json());
        let errorChatMsg: ChatMessage = {
          id: uuid(),
          role: "error",
          content:
            "There was an error generating a response. Chat history can't be saved at this time. If the problem persists, please contact the site administrator.",
          date: new Date().toISOString(),
        };
        let resultConversation;
        if (conversationId) {
          resultConversation = appState?.chatHistory?.find(
            (conv) => conv.id === conversationId
          );
          if (!resultConversation) {
            console.error("Conversation not found.");
            setIsLoading(false);
            setShowLoadingMessage(false);
            abortFuncs.current = abortFuncs.current.filter(
              (a) => a !== abortController
            );
            return;
          }
          resultConversation.messages.push(errorChatMsg);
        } else {
          setMessages([...messages, userMessage, errorChatMsg]);
          setIsLoading(false);
          setShowLoadingMessage(false);
          abortFuncs.current = abortFuncs.current.filter(
            (a) => a !== abortController
          );
          return;
        }
        dispatch({
          type: "UPDATE_CURRENT_CHAT",
          payload: resultConversation,
        });
        setMessages([...resultConversation.messages]);
        return;
      }
      if (response?.body) {
        const reader = response.body.getReader();
        let runningText = "";

        while (true) {
          // setProcessMessages(messageStatus.Processing);
          const { done, value } = await reader.read();
          if (done) break;

          var text = new TextDecoder("utf-8").decode(value);
          const objects = text.split("\n");
          objects.forEach((obj) => {
            runningText += obj;
          })

          result = JSON.parse(runningText);
          setShowLoadingMessage(false);
          dispatch({
            type: 'RESPONSE_RECEIVED',
            payload: result
          });
        }

        let resultConversation;
        if (conversationId) {
          resultConversation = appState?.chatHistory?.find(
            (conv) => conv.id === conversationId
          );
          if (!resultConversation) {
            console.error("Conversation not found.");
            setIsLoading(false);
            setShowLoadingMessage(false);
            abortFuncs.current = abortFuncs.current.filter(
              (a) => a !== abortController
            );
            return;
          }
          resultConversation.messages.push(...result.choices[0].messages);
        } else {
          resultConversation = {
            id: result.history_metadata.conversation_id,
            title: result.history_metadata.title,
            messages: [userMessage],
            date: result.history_metadata.date,
          };
          resultConversation.messages.push(...result.choices[0].messages);
        }
        if (!resultConversation) {
          setIsLoading(false);
          setShowLoadingMessage(false);
          abortFuncs.current = abortFuncs.current.filter(
            (a) => a !== abortController
          );
          return;
        }
        dispatch({
          type: "UPDATE_CURRENT_CHAT",
          payload: resultConversation,
        });
        setMessages([...messages, ...result.choices[0].messages]);
      }
    } catch (e) {
      if (!abortController.signal.aborted) {
        let errorMessage =
          "An error occurred. Please try again. If the problem persists, please contact the site administrator.";
        if (result.error?.message) {
          errorMessage = result.error.message;
        } else if (typeof result.error === "string") {
          errorMessage = result.error;
        }
        let errorChatMsg: ChatMessage = {
          id: uuid(),
          role: "error",
          content: errorMessage,
          date: new Date().toISOString(),
        };
        let resultConversation;
        if (conversationId) {
          resultConversation = appState?.chatHistory?.find(
            (conv) => conv.id === conversationId
          );
          if (!resultConversation) {
            console.error("Conversation not found.");
            setIsLoading(false);
            setShowLoadingMessage(false);
            abortFuncs.current = abortFuncs.current.filter(
              (a) => a !== abortController
            );
            return;
          }
          resultConversation.messages.push(errorChatMsg);
        } else {
          if (!result.history_metadata) {
            console.error("Error retrieving data.", result);
            setIsLoading(false);
            setShowLoadingMessage(false);
            abortFuncs.current = abortFuncs.current.filter(
              (a) => a !== abortController
            );
            return;
          }
          resultConversation = {
            id: result.history_metadata.conversation_id,
            title: result.history_metadata.title,
            messages: [userMessage],
            date: result.history_metadata.date,
          };
          resultConversation.messages.push(errorChatMsg);
        }
        if (!resultConversation) {
          setIsLoading(false);
          setShowLoadingMessage(false);
          abortFuncs.current = abortFuncs.current.filter(
            (a) => a !== abortController
          );
          return;
        }
        dispatch({
          type: "UPDATE_CURRENT_CHAT",
          payload: resultConversation,
        });
        setMessages([...messages, errorChatMsg]);
      } else {
        setMessages([...messages, userMessage]);
      }
    } finally {
      setIsLoading(false);
      setShowLoadingMessage(false);
      abortFuncs.current = abortFuncs.current.filter(
        (a) => a !== abortController
      );
      // setProcessMessages(messageStatus.Done);
    }
    return abortController.abort();
  };

  const newChat = () => {
    // setProcessMessages(messageStatus.Processing);
    setMessages([]);
    setIsCitationPanelOpen(false);
    setActiveCitation(undefined);
    dispatch({ type: "NEW_CHAT" });
    // setProcessMessages(messageStatus.NotRunning);
    setUserPromptScore(0)
  };

  const stopGenerating = () => {
    abortFuncs.current.forEach((a) => a.abort());
    setShowLoadingMessage(false);
    setIsLoading(false);
  };

  useEffect(() => {
    if (appState?.currentChat) {
      setMessages(appState.currentChat.messages);
    } else {
      setMessages([]);
    }
  }, [appState?.currentChat]);

  useEffect(() => {
    const chatStreamElement = chatMessageStreamEnd.current?.parentElement;
    if (chatStreamElement) {
      // Scroll to the bottom of the chat stream
      chatStreamElement.scrollTop =
        chatStreamElement.scrollHeight - chatStreamElement.clientHeight;
    }
  }, [messages, showLoadingMessage]);


  const onShowCitation = (citation: Citation) => {
    let filteredContent = citation.content.replace(/<>|<\/>/g, "");
    setActiveCitation([
      filteredContent,
      citation.id,
      citation.title ?? "",
      citation.filepath ?? "",
      "",
      "",
    ]);
    setIsCitationPanelOpen(true);
  };
  const parseCitationFromMessage = (message: ChatMessage) => {
    if (message.role === "tool") {
      try {
        const toolMessage = JSON.parse(message.content) as ToolMessageContent;
        return toolMessage.citations;
      } catch {
        return [];
      }
    }
    return [];
  };

  const disabledButton = () => {
    return (
      isLoading ||
      (messages && messages.length === 0) ||
      clearingChat ||
      appState?.chatHistoryLoadingState ===
        ChatHistoryLoadingState.Loading
    );
  };

  const onExampleClicked = (example: string) => {
    makeApiRequestWithCosmosDB(example);
  };

  return (
    <div className={styles.container} role="main">
      <Stack horizontal className={styles.chatRoot}>
        {appState?.isChatHistoryOpen &&
          appState?.isCosmosDBAvailable?.status !==
            CosmosDBStatus.NotConfigured && <ChatHistoryPanel />}
        <div className={styles.chatContainer}>
          {!messages || messages.length < 1 ? (
            <Stack className={styles.chatEmptyState}>
              <img
                src={NylLogo}
                className={styles.chatIcon}
                aria-hidden="true"
              />
              <h1 className={styles.chatEmptyStateTitle}>Start chatting</h1>
              <h2 className={styles.chatEmptyStateSubtitle}>
                This AI Chatbot can answer questions about Service Payments and
                Disbursements Procedures
              </h2>
              <h2 className={styles.chatEmptyStateSubtitle}>
                Try one of these example questions below
              </h2>
              <ExampleQuestions onExampleClicked={onExampleClicked} />
            </Stack>
          ) : (
            <div
              className={styles.chatMessageStream}
              style={{ marginBottom: isLoading ? "40px" : "0px" }}
              role="log"
            >
              {messages.map(
                (answer: ChatMessage, index: number) => (
                  <React.Fragment key={answer.id}>

                    {answer.role === "user" ? (
                      <div className={styles.chatMessageUser} tabIndex={0}>
                        <div className={styles.chatMessageUserMessage}>
                          {answer.content}
                        </div>
                      </div>
                    ) : answer.role === "assistant" ? (
                      <div className={styles.chatMessageGpt}>
                        <Answer
                          answer={{
                            answer: answer.content,
                            answerId: answer.id!,
                            question: messages[index - 1].content,
                            citations: parseCitationFromMessage(
                              messages[index - 1]
                            ),
                          }}
                          onCitationClicked={(c) => onShowCitation(c)}
                        />
                      </div>
                    ) : answer.role === "error" ? (
                      <div className={styles.chatMessageError}>
                        <Stack
                          horizontal
                          className={styles.chatMessageErrorContent}
                        >
                          <ErrorCircleRegular
                            className={styles.errorIcon}
                            style={{ color: "rgba(182, 52, 67, 1)" }}
                          />
                          <span>Error</span>
                        </Stack>
                        <span className={styles.chatMessageErrorContent}>
                          {answer.content}
                        </span>
                      </div>
                    ) : null}
                  </React.Fragment>
                )
              )}
              {showLoadingMessage && (
                <>
                  <div className={styles.chatMessageGpt}>
                    <Answer
                      answer={{
                        answer: "Generating answer...",
                        citations: [],
                      }}
                      onCitationClicked={() => null}
                    />
                  </div>
                </>
              )}
              <div ref={chatMessageStreamEnd} />
            </div>
          )}

          <Stack horizontal className={styles.chatInput}>
            {isLoading && (
              <Stack
                horizontal
                className={styles.stopGeneratingContainer}
                role="button"
                aria-label="Stop generating"
                tabIndex={0}
                onClick={stopGenerating}
                onKeyDown={(e: { key: string }) =>
                  e.key === "Enter" || e.key === " " ? stopGenerating() : null
                }
              >
                <SquareRegular
                  className={styles.stopGeneratingIcon}
                  aria-hidden="true"
                />
                <span className={styles.stopGeneratingText} aria-hidden="true">
                  Stop generating
                </span>
              </Stack>
            )}
            <Stack>
              {appState?.isCosmosDBAvailable?.status !==
                CosmosDBStatus.NotConfigured && (
                <CommandBarButton
                  role="button"
                  styles={{
                    icon: {
                      color: "#FFFFFF",
                    },
                    root: {
                      color: "#FFFFFF",
                      background:
                        "radial-gradient(109.81% 107.82% at 100.1% 90.19%, #0F6CBD 33.63%, #2D87C3 70.31%, #8DDDD8 100%)",
                    },
                    rootDisabled: {
                      background: "#BDBDBD",
                    },
                  }}
                  className={styles.newChatIcon}
                  iconProps={{ iconName: "Add" }}
                  onClick={newChat}
                  disabled={disabledButton()}
                  aria-label="start a new chat button"
                />
              )}
              <Dialog
                hidden={hideErrorDialog}
                onDismiss={handleErrorDialogClose}
                dialogContentProps={errorDialogContentProps}
                modalProps={modalProps}
              ></Dialog>
            </Stack>
            <QuestionInput
              clearOnSend
              placeholder="Type a new question..."
              disabled={isLoading}
              onSend={(question, id) => {
                makeApiRequestWithCosmosDB(question, id);
              }}
              onChangeVal={(question) => getQuestionInputScore(question)}
              conversationId={
                appState?.currentChat?.id
                  ? appState?.currentChat?.id
                  : undefined
              }
            />
          </Stack>

        </div>
        {messages &&
          messages.length > 0 &&
          isCitationPanelOpen &&
          activeCitation && (
            <Stack.Item
              className={styles.citationPanel}
              tabIndex={0}
              role="tabpanel"
              aria-label="Citations Panel"
            >
              <Stack
                aria-label="Citations Panel Header Container"
                horizontal
                className={styles.citationPanelHeaderContainer}
                horizontalAlign="space-between"
                verticalAlign="center"
              >
                <span
                  aria-label="Citations"
                  className={styles.citationPanelHeader}
                >
                  Citations
                </span>
                <IconButton
                  iconProps={{ iconName: "Cancel" }}
                  aria-label="Close citations panel"
                  onClick={() => setIsCitationPanelOpen(false)}
                />
              </Stack>
              <h5 className={styles.citationPanelTitle} tabIndex={0}>
                {activeCitation[2]}
              </h5>
              <div tabIndex={0}>
                <ReactMarkdown
                  linkTarget="_blank"
                  className={styles.citationPanelContent}
                  children={activeCitation[0]}
                  remarkPlugins={[remarkGfm]}
                  rehypePlugins={[rehypeRaw]}
                />
              </div>
            </Stack.Item>
          )}
      </Stack>
    </div>
  );
};

export default Chat;
