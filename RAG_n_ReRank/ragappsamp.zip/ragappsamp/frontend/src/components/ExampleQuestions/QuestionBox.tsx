import styles from "./ExampleQuestions.module.css";

interface Props {
  text: string;
  value: string;
  onClick: (value: string) => void;
}

export const QuestionBox = ({ text, value, onClick }: Props) => {
  return (
    <div className={styles.questionBox} onClick={() => onClick(value)}>
      <p className={styles.questionBoxText}>{text}</p>
    </div>
  );
};
