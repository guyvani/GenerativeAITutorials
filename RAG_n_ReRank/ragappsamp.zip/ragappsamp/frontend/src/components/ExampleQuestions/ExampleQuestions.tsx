import { QuestionBox } from "./QuestionBox";

import styles from "./ExampleQuestions.module.css";

export type ExampleModel = {
  text: string;
  value: string;
};

const EXAMPLES: ExampleModel[] = [
  {
    text: "What is the maximum amount loan that can be processed at point of call?",
    value:
      "What is the maximum amount loan that can be processed at point of call?",
  },
  {
    text: "Why did the client receive a 1099-R for the refund of excess contribution processed?",
    value:
      "Why did the client receive a 1099-R for the refund of excess contribution processed?",
  },
  {
    text: "Can the payor stop COM at point of call?",
    value: "Can the payor stop COM at point of call?",
  },
];

interface Props {
  onExampleClicked: (value: string) => void;
}

export const ExampleQuestions = ({ onExampleClicked }: Props) => {
  return (
    <ul className={styles.questionsNavList}>
      {EXAMPLES.map((x, i) => (
        <li key={i}>
          <QuestionBox
            text={x.text}
            value={x.value}
            onClick={onExampleClicked}
          />
        </li>
      ))}
    </ul>
  );
};
