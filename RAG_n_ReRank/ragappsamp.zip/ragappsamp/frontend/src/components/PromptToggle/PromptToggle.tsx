import * as React from "react";
import {
  AlignCenterHorizontal24Regular,
  AlignLeft24Regular,
  AlignRight24Regular,
  AppsListDetail24Regular,
  Flash24Regular,
  Flash24Filled,
  AppsListDetail24Filled,
} from "@fluentui/react-icons";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import { Tooltip } from "@mui/material";

export default function PromptToggle({
  setParentPromptStyle,
}: {
  setParentPromptStyle: React.Dispatch<React.SetStateAction<string>>;
}) {
  const [promptStyle, setPromptStyle] = React.useState<string | null>(
    "concise"
  );

  const handlePromptStyle = (
    event: React.MouseEvent<HTMLElement>,
    newPromptStyle: string | null
  ) => {
    if (newPromptStyle !== null) {
      setPromptStyle(newPromptStyle);
      setParentPromptStyle(newPromptStyle);
    }
  };

  return (
    <ToggleButtonGroup
      value={promptStyle}
      exclusive
      onChange={handlePromptStyle}
      aria-label="text alignment"
      sx={{ mr: 3 }}
    >
      <ToggleButton value="concise" aria-label="faster prompting">
        <Flash24Regular style={{ marginRight: 2 }} />
        Concise
      </ToggleButton>
      <ToggleButton value="detailed" aria-label="detailed prompting">
        <AppsListDetail24Regular style={{ marginRight: 2 }} />
        Detailed
      </ToggleButton>
    </ToggleButtonGroup>
  );
}
