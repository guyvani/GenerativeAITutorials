import { useState, useCallback, useRef, SetStateAction } from "react";
import { AskResponse, saveFeedback } from "../../api";
import { StarAddRegular, StarFilled } from "@fluentui/react-icons";
import {
  useId,
  Button,
  Toaster,
  useToastController,
  Toast,
  ToastTitle,
  Dialog,
  DialogTrigger,
  ToggleButton,
  DialogSurface,
  DialogBody,
  DialogTitle,
  DialogContent,
  DialogActions,
  Textarea,
  Divider,
  Radio,
  RadioGroup,
} from "@fluentui/react-components";
import { Rating } from "@fluentui/react";
import type { TextareaProps } from "@fluentui/react-components";
import { FluentProvider, teamsLightTheme } from "@fluentui/react-components";
import styles from "./Feedback.module.css";
import { useAppDispatch } from "../../state/AppProvider";

interface Props {
  answer: AskResponse;
}

export const Feedback = ({ answer }: Props) => {
  // If True, User Liked the response
  // If False, User Disliked the response
  // If Null, User did not rate the response

  const [rated, setRated] = useState<boolean | null>(!!answer.feedback);
  const [currentRating, setCurrentRating] = useState(answer.feedback?.stars ?? 0);
  const [showFeedbackWindow, setShowFeedbackWindow] = useState<boolean>(false);
  const [comment, setComment] = useState(answer.feedback?.comment);
  const [feedbackType, setFeedbackType] = useState("");

  const firstUpdate = useRef(true);
  const [errorText, setErrorText] = useState<string>("");
  
  const dispatch = useAppDispatch();

  const onFeedbackTypeChange = useCallback(
    (ev: any, option: { value: SetStateAction<string> }) => {
      setFeedbackType(option.value);
    },
    [setFeedbackType]
  );

  const onChange: TextareaProps["onChange"] = (ev, data) => {
    setComment(data.value);
  };

  const onRatingChange = (ev: any, rating: number | undefined) => {
    if (firstUpdate.current) {
      firstUpdate.current = false;
      return;
    }
    console.log(rating);
    if (rating) {
      setCurrentRating(rating);
    }
  };

  const toasterId = useId("feedbackToaster");
  const { dispatchToast } = useToastController(toasterId);
  const notify = () => {
    dispatchToast(
      <Toast>
        <ToastTitle>Error Submitting Feedback</ToastTitle>
      </Toast>,
      { intent: "error" }
    );
  };

  const submitFeedback = async () => {
    setErrorText("");

    if (currentRating !== 5 && feedbackType === "") {
      setErrorText(
        "Both rating and selection are required to submit feedback."
      );
      return;
    }

    setShowFeedbackWindow(false);
    console.log(comment);
    console.log(answer);
    try {
      if (answer.question !== undefined) {
        const chatContext = JSON.parse(answer.question);

        console.log(chatContext);
        // answer.answerId!

        const feedback = {
          messageId: answer.answerId!,
          stars: currentRating,
          comment: comment,
          feedbackType: String(feedbackType),
        };
        console.log(feedback)

        await saveFeedback(feedback);

        dispatch({ type: "FEEDBACK_PROVIDED", payload: feedback });
      } else {
        console.error("Response Data incomplete. Unable to insert document");
        notify();
      }
    } catch (error) {
      console.log(error)
      console.error("Error submitting feedback:", error);
      notify();
    }
  };

  const handleClick = async (ratedState: boolean) => {
    if (rated === true) {
      return;
    } else {
      setRated(ratedState);
      setShowFeedbackWindow(true);
    }
  };

  return (
    <>
      <FluentProvider theme={teamsLightTheme}>
        <Dialog open={showFeedbackWindow} modalType="modal">
          <DialogSurface>
            <DialogBody>
              <DialogTitle>Provide Feedback</DialogTitle>

              <DialogContent>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginBottom: 5,
                  }}
                >
                  <p style={{ fontSize: 16 }}>Rate Tool Response: </p>
                  <span style={{ color: "red", paddingRight: 3 }}>* </span>
                  <Rating
                    allowZeroStars
                    size={1}
                    rating={currentRating}
                    onChange={onRatingChange}
                  />
                </div>

                {currentRating !== 5 && currentRating !== 0 && (
                  <>
                    <Divider style={{ marginBottom: "0.3rem" }} />
                    How could it be better?
                    <span style={{ color: "red" }}>*</span>
                    <br />
                    <RadioGroup
                      name="feedbackType"
                      layout="vertical"
                      value={feedbackType}
                      onChange={onFeedbackTypeChange}
                    >
                      <Radio
                        value="inaccurate"
                        label="The response was inaccurate, with helpful citation"
                      />
                      <Radio
                        value="partial"
                        label="The response was incomplete"
                      />
                      <Radio
                        value="ambiguous"
                        label="The response was not clear enough or hard to act on"
                      />
                      <Radio
                        value="refused"
                        label="The tool did not answer even though it should have"
                      />
                      <Radio
                        value="misinterpreted"
                        label="The tool did not understand the question or context"
                      />
                      <Radio
                        value="inaccurateNoCite"
                        label="The response was inaccurate and did not contain a useful citations"
                      />
                    </RadioGroup>
                    <Divider
                      style={{ marginTop: "0.5rem", marginBottom: "1rem" }}
                    />
                    <Textarea
                      style={{ display: "flex", marginTop: 5 }}
                      size="large"
                      value={comment}
                      onChange={onChange}
                      placeholder="Additional Comments"
                    />
                  </>
                )}
              </DialogContent>

              <DialogActions>
                <DialogTrigger disableButtonEnhancement></DialogTrigger>

                <Button
                  onClick={() => submitFeedback()}
                  style={{ backgroundColor: "#9fd89f" }}
                >
                  Submit Feedback
                </Button>
              </DialogActions>
            </DialogBody>
            {errorText && (
              <div>
                <span style={{ color: "red" }}>{errorText}</span> <br />
              </div>
            )}
          </DialogSurface>
        </Dialog>
        <Toaster toasterId={toasterId} />
        <div className={styles.feedbackContainer}>
          <ToggleButton
            checked={rated === true}
            onClick={() => handleClick(true)}
            icon={rated === true ? <StarFilled /> : <StarAddRegular />}
            className={styles.toggleButton}
            aria-label={
              rated === true ? "This question is rated" : "Rate this answer"
            }
          />
        </div>
      </FluentProvider>
    </>
  );
};
