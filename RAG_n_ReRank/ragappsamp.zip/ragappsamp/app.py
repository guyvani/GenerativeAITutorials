from typing import List
from backend.history.cosmosdbservice import CosmosConversationClient
from backend.auth.auth_utils import get_authenticated_user_details
from backend.models.models import Conversation, GenerateResponse, HistoryReadRequest, GenerateRequest, RequestMessage, DeleteRequest, RenameRequest, ClearRequest, FeedbackRequest
from dotenv import load_dotenv
from flask import Flask, Response, request, jsonify
import json
import os
import logging
import requests
import openai
from azure.cosmos import CosmosClient
import uuid
# Fixing MIME types for static files under Windows
import mimetypes
# from flask_swagger_ui import get_swaggerui_blueprint

from flask_pydantic import validate

mimetypes.add_type('application/javascript', '.js')
mimetypes.add_type('text/css', '.css')


load_dotenv()

app = Flask(__name__)

# Swagger UI route
# SWAGGER_URL = '/swagger-ui'
# API_URL = '/swagger.yaml'
# swaggerui_blueprint = get_swaggerui_blueprint(
#     SWAGGER_URL,
#     API_URL,
#     config={
#         'app_name': "One Assist Swagger"
#     }
# )

# app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)

SITE_ROOT = os.path.realpath(os.path.dirname(__file__))


@app.after_request
def add_response_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Cache-Control'] = 'no-store'
    response.headers['Pragma'] = 'no-cache'
    return response


@app.route("/", defaults={"path": "index.html"})
@app.route("/<path:path>")
def static_file(path):
    return app.send_static_file(path)


# ACS Integration Settings
AZURE_SEARCH_SERVICE = os.environ.get("AZURE_SEARCH_SERVICE")
AZURE_SEARCH_INDEX = os.environ.get("AZURE_SEARCH_INDEX")
AZURE_SEARCH_KEY = os.environ.get("AZURE_SEARCH_KEY")
AZURE_SEARCH_USE_SEMANTIC_SEARCH = os.environ.get(
    "AZURE_SEARCH_USE_SEMANTIC_SEARCH", False)
AZURE_SEARCH_SEMANTIC_SEARCH_CONFIG = os.environ.get(
    "AZURE_SEARCH_SEMANTIC_SEARCH_CONFIG", "default")
AZURE_SEARCH_TOP_K = os.environ.get("AZURE_SEARCH_TOP_K", 5)
AZURE_SEARCH_ENABLE_IN_DOMAIN = os.environ.get(
    "AZURE_SEARCH_ENABLE_IN_DOMAIN", "true")
AZURE_SEARCH_CONTENT_COLUMNS = os.environ.get("AZURE_SEARCH_CONTENT_COLUMNS")
AZURE_SEARCH_FILENAME_COLUMN = os.environ.get("AZURE_SEARCH_FILENAME_COLUMN")
AZURE_SEARCH_TITLE_COLUMN = os.environ.get("AZURE_SEARCH_TITLE_COLUMN")
AZURE_SEARCH_URL_COLUMN = os.environ.get("AZURE_SEARCH_URL_COLUMN")

# AOAI Integration Settings
AZURE_OPENAI_RESOURCE = os.environ.get("AZURE_OPENAI_RESOURCE")
AZURE_OPENAI_MODEL = os.environ.get("AZURE_OPENAI_MODEL")
AZURE_OPENAI_KEY = os.environ.get("AZURE_OPENAI_KEY")
AZURE_OPENAI_TEMPERATURE = os.environ.get("AZURE_OPENAI_TEMPERATURE", 0)
AZURE_OPENAI_TOP_P = os.environ.get("AZURE_OPENAI_TOP_P", 1.0)
AZURE_OPENAI_MAX_TOKENS = os.environ.get("AZURE_OPENAI_MAX_TOKENS", 1000)
AZURE_OPENAI_STOP_SEQUENCE = os.environ.get("AZURE_OPENAI_STOP_SEQUENCE")
AZURE_OPENAI_SYSTEM_MESSAGE = os.environ.get(
    "AZURE_OPENAI_SYSTEM_MESSAGE", "You are an AI assistant that helps people find information.")
AZURE_OPENAI_API_VERSION = os.environ.get(
    "AZURE_OPENAI_API_VERSION", "2023-06-01-preview")
AZURE_OPENAI_STREAM = os.environ.get("AZURE_OPENAI_STREAM", "true")
# Name of the model, e.g. 'gpt-35-turbo' or 'gpt-4'
AZURE_OPENAI_MODEL_NAME = os.environ.get(
    "AZURE_OPENAI_MODEL_NAME", "gpt-35-turbo")

# CosmosDB Integrating Settings
AZURE_COSMOSDB_URL = os.getenv("AZURE_COSMOSDB_URL")
AZURE_COSMOSDB_ACCOUNT_KEY = os.environ.get("AZURE_COSMOSDB_ACCOUNT_KEY")
AZURE_COSMOSDB_NAME = os.environ.get("AZURE_COSMOSDB_DATABASE")

AZURE_COSMOSDB_CHAT_HISTORY_CONTAINER = os.getenv(
    "AZURE_COSMOSDB_CHAT_HISTORY_CONTAINER")

SHOULD_STREAM = True if AZURE_OPENAI_STREAM.lower() == "true" else False

client = CosmosClient(AZURE_COSMOSDB_URL,
                      credential=AZURE_COSMOSDB_ACCOUNT_KEY)
database = client.get_database_client(AZURE_COSMOSDB_NAME)

COSMOS_ERROR = "CosmosDB is not configured"

# Initialize a CosmosDB Client with Auth and Containers
if AZURE_COSMOSDB_NAME and AZURE_COSMOSDB_URL and AZURE_COSMOSDB_CHAT_HISTORY_CONTAINER:
    try:
        cosmos_endpoint = AZURE_COSMOSDB_URL

        credential = AZURE_COSMOSDB_ACCOUNT_KEY

        cosmos_conversation_client = CosmosConversationClient(
            cosmosdb_endpoint=cosmos_endpoint,
            credential=credential,
            database_name=AZURE_COSMOSDB_NAME,
            container_name=AZURE_COSMOSDB_CHAT_HISTORY_CONTAINER
        )
    except Exception as e:
        logging.exception("Exception in CosmosDB initialization", e)
        cosmos_conversation_client = None


def format_as_ndjson(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False) + "\n"


def conversation_internal(request_body: dict):
    print("REQUEST_BODY")
    print(request_body)
    from backend.utilities.helpers.OrchestratorHelper import Orchestrator
    message_orchestrator = Orchestrator()

    try:
        user_message = request_body["messages"][-1]['content']
        prompt_style = request_body["promptStyle"]
        history_metadata = request_body['history_metadata']
        conversation_id = history_metadata['conversation_id']

        print(conversation_id)

        user_assistant_messages = list(filter(lambda x: x['role'] in (
            'user', 'assistant'), request_body["messages"][0:-1]))
        chat_history = []

        # Taking care of the last message if it is not paired
        for i in range(0, len(user_assistant_messages) - 1, 2):
            chat_history.append(
                (user_assistant_messages[i]['content'], user_assistant_messages[i+1]['content']))

        if len(user_assistant_messages) % 2 == 1:
            # For odd number of messages, append the last user message
            chat_history.append((user_assistant_messages[-1]['content'], ""))

        from backend.utilities.helpers.ConfigHelper import ConfigHelper
        messages = message_orchestrator.handle_message(user_message=user_message, chat_history=chat_history, conversation_id=conversation_id,
                                                       orchestrator=ConfigHelper.get_active_config_or_default().orchestrator, prompt_style=prompt_style)

        return messages

    except Exception as e:
        logging.exception(f"Exception in in conversation_internal: {e}")
        raise e


@app.route("/history/generate", methods=["POST"])
@validate()
def add_conversation(body: GenerateRequest):
    authenticated_user = get_authenticated_user_details(
        request_headers=request.headers)
    user_id = authenticated_user['user_principal_id']
    user_name = authenticated_user['user_name']

    # check request for conversation_id
    conversation_id = body.conversation_id

    try:
        # make sure cosmos is configured
        if not cosmos_conversation_client:
            raise SystemError(COSMOS_ERROR)

        # check for the conversation_id, if the conversation is not set, we will create a new one
        history_metadata = {}
        if not conversation_id:
            print('Generating Title For the Conversation')
            title = generate_title(body.messages)
            print(f'Generated Title: {title}')
            conversation_dict = cosmos_conversation_client.create_conversation(
                user_id=user_id, title=title)
            conversation_id = conversation_dict['id']
            history_metadata['title'] = title
            history_metadata['date'] = conversation_dict['createdAt']

        # Format the incoming message object in the "chat/completions" messages format
        # then write it to the conversation history in cosmos

        messages = body.messages
        if len(messages) > 0 and messages[-1].role == "user":
            question = cosmos_conversation_client.create_message(
                conversation_id=conversation_id,
                user_id=user_id,
                user_name=user_name,
                input_message=messages[-1].model_dump()
            )
        else:
            raise ValueError("No user message found")

        # Submit request to Chat Completions for response
        request_body = body.model_dump()
        history_metadata['conversation_id'] = conversation_id
        request_body['history_metadata'] = history_metadata
        print(f'convo: {conversation_internal}')
        generated_messages = conversation_internal(request_body)

        responses = []
        if len(generated_messages) > 0 and generated_messages[-1]["role"] == "assistant":
            if len(generated_messages) > 1 and generated_messages[-2]["role"] == "tool":
                # write the tool message first
                response = cosmos_conversation_client.create_message(
                    conversation_id=conversation_id,
                    user_id=user_id,
                    user_name=user_name,
                    input_message=generated_messages[-2],
                    question_id=question["id"]
                )
                responses.append(response)

            # write the assistant message
            response = cosmos_conversation_client.create_message(
                conversation_id=conversation_id,
                user_id=user_id,
                user_name=user_name,
                input_message=generated_messages[-1],
                question_id=question["id"]
            )
            responses.append(response)

        else:
            raise SystemError("No bot messages found")

        response_obj = {
            "id": "response.id",
            "model": os.getenv("AZURE_OPENAI_MODEL"),
            "created": "response.created",
            "object": "response.object",
            "choices": [{
                "messages": responses
            }],
            "history_metadata": history_metadata
        }

        return jsonify(GenerateResponse.model_validate(response_obj).model_dump()), 200

    except Exception as e:
        logging.exception(f"Exception in /history/generate {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/history/delete", methods=["DELETE"])
@validate()
def delete_conversation(body: DeleteRequest):
    # get the user id from the request headers
    authenticated_user = get_authenticated_user_details(
        request_headers=request.headers)
    user_id = authenticated_user['user_principal_id']

    # check request for conversation_id
    conversation_id = body.conversation_id
    try:
        if not conversation_id:
            return jsonify({"error": "conversation_id is required"}), 400

        # delete the conversation messages from cosmos first
        cosmos_conversation_client.delete_messages(
            conversation_id, user_id)

        # Now delete the conversation
        cosmos_conversation_client.delete_conversation(
            user_id, conversation_id)

        return jsonify({"message": "Successfully deleted conversation and messages", "conversation_id": conversation_id}), 200
    except Exception as e:
        logging.exception("Exception in /history/delete")
        return jsonify({"error": str(e)}), 500


@app.route("/history/list", methods=["GET"])
def list_conversations():
    authenticated_user = get_authenticated_user_details(
        request_headers=request.headers)
    user_id = authenticated_user['user_principal_id']

    # get the conversations from cosmos
    conversations = cosmos_conversation_client.get_conversations(user_id)
    if not isinstance(conversations, list):
        return jsonify({"error": f"No conversations for {user_id} were found"}), 404

    # return the conversation ids

    return jsonify(conversations), 200


@app.route("/history/read", methods=["POST"])
@validate()
def get_conversation(body: HistoryReadRequest):
    authenticated_user = get_authenticated_user_details(
        request_headers=request.headers)
    user_id = authenticated_user['user_principal_id']

    # check request for conversation_id
    conversation_id = body.conversation_id

    if not conversation_id:
        return jsonify({"error": "conversation_id is required"}), 400

    # get the conversation object and the related messages from cosmos
    conversation = cosmos_conversation_client.get_conversation(
        user_id, conversation_id)
    # return the conversation id and the messages in the bot frontend format
    if not conversation:
        return jsonify({"error": f"Conversation {conversation_id} was not found. It either does not exist or the logged in user does not have access to it."}), 404

    # get the messages for the conversation from cosmos
    conversation_messages = cosmos_conversation_client.get_messages(
        user_id, conversation_id)

    return jsonify(Conversation.model_validate({"conversation_id": conversation_id, "messages": conversation_messages}).model_dump()), 200


@app.route("/history/rename", methods=["POST"])
@validate()
def rename_conversation(body: RenameRequest):
    authenticated_user = get_authenticated_user_details(
        request_headers=request.headers)
    user_id = authenticated_user['user_principal_id']

    # check request for conversation_id
    conversation_id = body.conversation_id

    if not conversation_id:
        return jsonify({"error": "conversation_id is required"}), 400

    # get the conversation from cosmos
    conversation = cosmos_conversation_client.get_conversation(
        user_id, conversation_id)
    if not conversation:
        return jsonify({"error": f"Conversation {conversation_id} was not found. It either does not exist or the logged in user does not have access to it."}), 404

    # update the title
    title = body.title
    if not title:
        return jsonify({"error": "title is required"}), 400
    conversation['title'] = title
    updated_conversation = cosmos_conversation_client.upsert_conversation(
        conversation)

    return jsonify(updated_conversation), 200


@app.route("/history/delete_all", methods=["DELETE"])
def delete_all_conversations():
    # get the user id from the request headers
    authenticated_user = get_authenticated_user_details(
        request_headers=request.headers)
    user_id = authenticated_user['user_principal_id']

    # get conversations for user
    try:
        conversations = cosmos_conversation_client.get_conversations(user_id)
        if not conversations:
            return jsonify({"error": f"No conversations for {user_id} were found"}), 404

        # delete each conversation
        for conversation in conversations:
            # delete the conversation messages from cosmos first
            cosmos_conversation_client.delete_messages(
                conversation['id'], user_id)

            # Now delete the conversation
            cosmos_conversation_client.delete_conversation(
                user_id, conversation['id'])

        return jsonify({"message": f"Successfully deleted conversation and messages for user {user_id}"}), 200

    except Exception as e:
        logging.exception("Exception in /history/delete_all")
        return jsonify({"error": str(e)}), 500


@app.route("/history/clear", methods=["POST"])
@validate()
def clear_messages(body: ClearRequest):
    # get the user id from the request headers
    authenticated_user = get_authenticated_user_details(
        request_headers=request.headers)
    user_id = authenticated_user['user_principal_id']

    # check request for conversation_id
    conversation_id = body.conversation_id
    try:
        if not conversation_id:
            return jsonify({"error": "conversation_id is required"}), 400

        # delete the conversation messages from cosmos
        cosmos_conversation_client.delete_messages(
            conversation_id, user_id)

        return jsonify({"message": "Successfully deleted messages in conversation", "conversation_id": conversation_id}), 200
    except Exception as e:
        logging.exception("Exception in /history/clear_messages")
        return jsonify({"error": str(e)}), 500


@app.route("/history/ensure", methods=["GET"])
def ensure_cosmos():
    if not AZURE_COSMOSDB_URL:
        return jsonify({"error": COSMOS_ERROR}), 404

    if not cosmos_conversation_client or not cosmos_conversation_client.ensure():
        return jsonify({"error": "CosmosDB is not working"}), 500

    return jsonify({"message": "CosmosDB is configured and working"}), 200

def generate_title(conversation_messages: List[RequestMessage]):
    # make sure the messages are sorted by _ts descending
    print('Starting title generation')
    title_prompt = 'Summarize the conversation so far into a 4-word or less title. Do not use any quotation marks or punctuation. Respond with a json object in the format {{"title": string}}. Do not include any other commentary or description.'

    messages = [{'role': msg.role, 'content': msg.content}
                for msg in conversation_messages]
    messages.append({'role': 'user', 'content': title_prompt})

    print(f"Input messages for title generation: {conversation_messages}")

    try:
        print('Setting up API Call for Title Generation')
        # Submit prompt to Chat Completions for response
        base_url = f"https://{AZURE_OPENAI_RESOURCE}.openai.azure.com/"
        openai.api_type = "azure"
        openai.api_base = base_url
        openai.api_version = "2023-03-15-preview"
        openai.api_key = AZURE_OPENAI_KEY
        completion = openai.ChatCompletion.create(
            engine=AZURE_OPENAI_MODEL,
            messages=messages,
            temperature=1,
            max_tokens=64
        )

        print(f'API Response {completion}')

        try:
            completion_content = completion['choices'][0]['message']['content']
            logging.debug(
                f"Completion content to be parsed: {completion_content}")

            # Parse the JSON content from the API response
            parsed_content = json.loads(completion_content)
            logging.debug(f"Parsed JSON content: {parsed_content}")

            title = parsed_content['title']
            logging.info(f"Title generated successfully: {title}")
            return title
        except json.JSONDecodeError as json_err:
            # Log the JSON parsing error
            logging.error(f"JSON parsing failed: {json_err}")
            logging.error(
                f"Invalid JSON content: {completion['choices'][0]['message']['content']}")
            raise

    except Exception as e:
        print(f'Exception in generate_title {e}')
        fallback_title = messages[-2]['content'] if len(
            messages) > 1 else "Conversation"
        print(f"Falling back to default title: {fallback_title}")
        return fallback_title


def is_chat_model():
    if 'gpt-4' in AZURE_OPENAI_MODEL_NAME.lower():
        return True
    return False


def should_use_data():
    if AZURE_SEARCH_SERVICE and AZURE_SEARCH_INDEX and AZURE_SEARCH_KEY:
        return True
    return False


def prepare_body_headers_with_data(request):
    request_messages = request.json["messages"]

    body = {
        "messages": request_messages,
        "temperature": AZURE_OPENAI_TEMPERATURE,
        "max_tokens": AZURE_OPENAI_MAX_TOKENS,
        "top_p": AZURE_OPENAI_TOP_P,
        "stop": AZURE_OPENAI_STOP_SEQUENCE.split("|") if AZURE_OPENAI_STOP_SEQUENCE else [],
        "stream": SHOULD_STREAM,
        "dataSources": [
            {
                "type": "AzureCognitiveSearch",
                "parameters": {
                    "endpoint": f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
                    "key": AZURE_SEARCH_KEY,
                    "indexName": AZURE_SEARCH_INDEX,
                    "fieldsMapping": {
                        "contentField": AZURE_SEARCH_CONTENT_COLUMNS.split("|") if AZURE_SEARCH_CONTENT_COLUMNS else [],
                        "titleField": AZURE_SEARCH_TITLE_COLUMN if AZURE_SEARCH_TITLE_COLUMN else None,
                        "urlField": AZURE_SEARCH_URL_COLUMN if AZURE_SEARCH_URL_COLUMN else None,
                        "filepathField": AZURE_SEARCH_FILENAME_COLUMN if AZURE_SEARCH_FILENAME_COLUMN else None
                    },
                    "inScope": True if AZURE_SEARCH_ENABLE_IN_DOMAIN.lower() == "true" else False,
                    "topNDocuments": AZURE_SEARCH_TOP_K,
                    "queryType": "semantic" if AZURE_SEARCH_USE_SEMANTIC_SEARCH.lower() == "true" else "simple",
                    "semanticConfiguration": AZURE_SEARCH_SEMANTIC_SEARCH_CONFIG if AZURE_SEARCH_USE_SEMANTIC_SEARCH.lower() == "true" and AZURE_SEARCH_SEMANTIC_SEARCH_CONFIG else "",
                    "roleInformation": AZURE_OPENAI_SYSTEM_MESSAGE
                }
            }
        ]
    }

    chatgpt_url = f"https://{AZURE_OPENAI_RESOURCE}.openai.azure.com/openai/deployments/{AZURE_OPENAI_MODEL}"
    if is_chat_model():
        chatgpt_url += "/chat/completions?api-version=2023-03-15-preview"
    else:
        chatgpt_url += "/completions?api-version=2023-03-15-preview"

    headers = {
        'Content-Type': 'application/json',
        'api-key': AZURE_OPENAI_KEY,
        'chatgpt_url': chatgpt_url,
        'chatgpt_key': AZURE_OPENAI_KEY,
        "x-ms-useragent": "GitHubSampleWebApp/PublicAPI/1.0.0"
    }

    return body, headers


def stream_with_data(body, headers, endpoint):
    s = requests.Session()
    response = {
        "id": "",
        "model": "",
        "created": 0,
        "object": "",
        "choices": [{
            "messages": []
        }]
    }
    try:
        with s.post(endpoint, json=body, headers=headers, stream=True) as r:
            for line in r.iter_lines(chunk_size=10):
                if line:
                    lineJson = json.loads(
                        line.lstrip(b'data:').decode('utf-8'))
                    if 'error' in lineJson:
                        yield json.dumps(lineJson).replace("\n", "\\n") + "\n"
                    response["id"] = lineJson["id"]
                    response["model"] = lineJson["model"]
                    response["created"] = lineJson["created"]
                    response["object"] = lineJson["object"]

                    role = lineJson["choices"][0]["messages"][0]["delta"].get(
                        "role")
                    if role == "tool":
                        response["choices"][0]["messages"].append(
                            lineJson["choices"][0]["messages"][0]["delta"])
                    elif role == "assistant":
                        response["choices"][0]["messages"].append({
                            "role": "assistant",
                            "content": ""
                        })
                    else:
                        deltaText = lineJson["choices"][0]["messages"][0]["delta"]["content"]
                        if deltaText != "[DONE]":
                            response["choices"][0]["messages"][1]["content"] += deltaText

                    yield json.dumps(response).replace("\n", "\\n") + "\n"
    except Exception as e:
        yield json.dumps({"error": str(e)}).replace("\n", "\\n") + "\n"


def conversation_with_data(request):
    body, headers = prepare_body_headers_with_data(request)
    endpoint = f"https://{AZURE_OPENAI_RESOURCE}.openai.azure.com/openai/deployments/{AZURE_OPENAI_MODEL}/extensions/chat/completions?api-version={AZURE_OPENAI_API_VERSION}"

    if not SHOULD_STREAM:
        r = requests.post(endpoint, headers=headers, json=body)
        status_code = r.status_code
        r = r.json()

        return Response(json.dumps(r).replace("\n", "\\n"), status=status_code)
    else:
        if request.method == "POST":
            return Response(stream_with_data(body, headers, endpoint), mimetype='text/event-stream')
        else:
            return Response(None, mimetype='text/event-stream')


def stream_without_data(response):
    responseText = ""
    for line in response:
        deltaText = line["choices"][0]["delta"].get('content')
        if deltaText and deltaText != "[DONE]":
            responseText += deltaText

        response_obj = {
            "id": line["id"],
            "model": line["model"],
            "created": line["created"],
            "object": line["object"],
            "choices": [{
                "messages": [{
                    "role": "assistant",
                    "content": responseText
                }]
            }]
        }
        yield json.dumps(response_obj).replace("\n", "\\n") + "\n"


def conversation_without_data(request):
    openai.api_type = "azure"
    openai.api_base = f"https://{AZURE_OPENAI_RESOURCE}.openai.azure.com/"
    openai.api_version = "2023-03-15-preview"
    openai.api_key = AZURE_OPENAI_KEY

    request_messages = request.json["messages"]
    messages = [
        {
            "role": "system",
            "content": AZURE_OPENAI_SYSTEM_MESSAGE
        }
    ]

    for message in request_messages:
        messages.append({
            "role": message["role"],
            "content": message["content"]
        })

    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages=messages,
        temperature=float(AZURE_OPENAI_TEMPERATURE),
        max_tokens=int(AZURE_OPENAI_MAX_TOKENS),
        top_p=float(AZURE_OPENAI_TOP_P),
        stop=AZURE_OPENAI_STOP_SEQUENCE.split(
            "|") if AZURE_OPENAI_STOP_SEQUENCE else None,
        stream=SHOULD_STREAM
    )

    if not SHOULD_STREAM:
        response_obj = {
            "id": response,
            "model": response.model,
            "created": response.created,
            "object": response.object,
            "choices": [{
                "messages": [{
                    "role": "assistant",
                    "content": response.choices[0].message.content
                }]
            }]
        }

        return jsonify(response_obj), 200
    else:
        if request.method == "POST":
            return Response(stream_without_data(response), mimetype='text/event-stream')
        else:
            return Response(None, mimetype='text/event-stream')


@app.route("/api/conversation/azure_byod", methods=["GET", "POST"])
def conversation_azure_byod():
    try:
        use_data = should_use_data()
        if use_data:
            return conversation_with_data(request)
        else:
            return conversation_without_data(request)
    except Exception as e:
        logging.exception("Exception in /api/conversation/azure_byod")
        return jsonify({"error": str(e)}), 500


@app.route("/api/conversation/custom", methods=["GET", "POST"])
def conversation_custom():
    from backend.utilities.helpers.OrchestratorHelper import Orchestrator
    message_orchestrator = Orchestrator()

    try:
        user_message = request.json["messages"][-1]['content']
        conversation_id = request.json["conversation_id"]
        prompt_style = request.json["promptStyle"]
        user_assistant_messages = list(filter(lambda x: x['role'] in (
            'user', 'assistant'), request.json["messages"][0:-1]))
        chat_history = []

        # Taking care of the last message if it is not paired
        for i in range(0, len(user_assistant_messages) - 1, 2):
            chat_history.append(
                (user_assistant_messages[i]['content'], user_assistant_messages[i+1]['content']))

        if len(user_assistant_messages) % 2 == 1:
            # For odd number of messages, append the last user message
            chat_history.append((user_assistant_messages[-1]['content'], ""))

        from backend.utilities.helpers.ConfigHelper import ConfigHelper
        messages = message_orchestrator.handle_message(user_message=user_message, chat_history=chat_history, conversation_id=conversation_id,
                                                       orchestrator=ConfigHelper.get_active_config_or_default().orchestrator, prompt_style=prompt_style)

        response_obj = {
            "id": "response.id",
            "model": os.getenv("AZURE_OPENAI_MODEL"),
            "created": "response.created",
            "object": "response.object",
            "choices": [{
                "messages": messages
            }]
        }

        return jsonify(response_obj), 200

    except Exception as e:
        logging.exception("Exception in /api/conversation/custom")
        return jsonify({"error": str(e)}), 500


@app.route("/api/feedback", methods=["POST"])
@validate()
def submit_feedback(body: FeedbackRequest):
    print("inside submit feedback")
    print(body)

    authenticated_user = get_authenticated_user_details(
        request_headers=request.headers)
    user_id = authenticated_user['user_principal_id']

    message_id = body.messageId
    stars = body.stars

    if not message_id:
        return jsonify({'error': 'message Id is required'}), 400

    if not stars:
        return jsonify({'error': 'stars value is required'}), 400

    # Check if the user has already rated this response

    # If still working, now try with response (this is where I expect it to possibly break given the length)
    try:
        item = cosmos_conversation_client.provide_feedback(
            user_id, message_id, {'stars': body.stars, 'comment': body.comment, 'feedback_type': body.feedbackType})
    except Exception as e:
        print(f'Exception {e} occurred')
        return jsonify({'error': f"Failed to update document in the database, {e}"}), 500

    if item:
        print(f"Rating updated successfully for message_id: {item['id']}")
        return jsonify({'message': 'Rating added successfully', 'message_id': item['id']}), 200
    else:
        return jsonify({'error': "Unable to find the message to provide feedback"}), 404


@app.route('/.auth/me', methods=["GET"])
def get_user_info():
    with open(os.path.join(SITE_ROOT, "mockData", "userInfo.json")) as f:
        data = json.load(f)
    return data, 200


if __name__ == "__main__":
    app.run()